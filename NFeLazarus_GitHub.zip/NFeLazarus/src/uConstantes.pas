unit uConstantes;

{$mode objfpc}{$H+}

interface

uses
  SysUtils, Graphics;

const
  APP_TITLE   = 'Sistema de Devolucao NF-e v2.0';
  DB_FILENAME = 'nfe_devolucao.db';

  // Cores (BGR no Delphi/Lazarus)
  COR_BG_DARK    = TColor($2E1F1A);
  COR_BG_CARD    = TColor($3B2B25);
  COR_BG_FIELD   = TColor($331E1E);
  COR_ACCENT     = TColor($F78E4F);
  COR_ACCENT2    = TColor($A7C900);
  COR_DANGER     = TColor($5252FF);
  COR_WARNING    = TColor($40ABFF);
  COR_TEXT       = TColor($F6EAE8);
  COR_TEXT_MUTED = TColor($B09288);
  COR_BORDER     = TColor($5C3D33);
  COR_SUCCESS    = TColor($AEF069);

  MAX_TENTATIVAS    = 5;
  BLOQUEIO_SEGUNDOS = 60;

  STATUS_REGISTRADA = 'Registrada';
  STATUS_CONCLUIDA  = 'Concluida';
  STATUS_CANCELADA  = 'Cancelada';

var
  DB_PATH: string;

const
  UF_LIST: array[0..26] of string = (
    'AC','AL','AM','AP','BA','CE','DF','ES','GO','MA',
    'MG','MS','MT','PA','PB','PE','PI','PR','RJ','RN',
    'RO','RR','RS','SC','SE','SP','TO');

  CST_ICMS: array[0..10] of string = (
    '00','10','20','30','40','41','50','51','60','70','90');

  CST_PIS_COFINS: array[0..11] of string = (
    '01','02','03','04','05','06','07','08','09','49','50','99');

  MODALIDADE_FRETE: array[0..5] of string = (
    '0','1','2','3','4','9');

  FORMA_PAGAMENTO: array[0..11] of string = (
    '01','02','03','04','05','10','15','16','17','18','90','99');

type
  TPerfilUsuario = (puAdmin, puOperador);

  TUsuario = record
    ID     : Integer;
    Nome   : string;
    Login  : string;
    Perfil : TPerfilUsuario;
    Ativo  : Boolean;
  end;

  TDadosNFe = record
    ChaveAcesso, NatOp, RefNFe, CFOP, Serie, NumNF      : string;
    DhEmi, DhSaiEnt, TpNF, FinNFe, CUF, IdDest          : string;
    IndFinal                                              : string;
    EmitCNPJ, EmitxNome, EmitxFant, EmitIE, EmitIEST    : string;
    EmitIM, EmitCRT, EmitCNAE, EmitFone                  : string;
    EmitxLgr, EmitNro, EmitxCpl, EmitxBairro             : string;
    EmitxMun, EmitUF, EmitCEP                            : string;
    DestCNPJ, DestxNome, DestEmail, DestIE, DestISUF     : string;
    DestIndIE, DestxLgr, DestNro, DestxCpl, DestxBairro : string;
    DestxMun, DestUF, DestCEP                            : string;
    ProdcProd, ProdcEAN, ProdxProd, ProdNCM, ProdCEST   : string;
    ProduCom, ProdqCom, ProdvUnCom, ProdvProd            : string;
    ProduTrib, ProdqTrib, ProdvUnTrib                    : string;
    ProdvFrete, ProdvSeg, ProdvDesc, ProdvOutro          : string;
    ProdIndTot                                           : string;
    IcmsOrig, IcmsCST, IcmsModBC, IcmsvBC               : string;
    IcmspICMS, IcmsvICMS, IcmspFCP, IcmsvFCP            : string;
    RtpCBS, RtvCBS, RtpIBS, RtvIBS, RtpIS, RtvIS        : string;
    IpicEnq, IpiCST, IpivBC, IpipIPI, IpivIPI           : string;
    PisCST, PisvBC, PispPIS, PisvPIS                    : string;
    CofinsCST, CofinsvBC, CofinspCOFINS, CofinsvCOFINS  : string;
    TotalvBC, TotalvICMS, TotalvFCP, TotalvBCST         : string;
    TotalvST, TotalvFCPST, TotalvProd, TotalvFrete      : string;
    TotalvSeg, TotalvDesc, TotalvIPI, TotalvIPIDevol     : string;
    TotalvPIS, TotalvCOFINS, TotalvOutro                 : string;
    TotalvNF, TotalvTotTrib                              : string;
    TranspModFrete, TranspCNPJ, TranspxNome, TranspIE   : string;
    TranspxEnder, TranspxMun, TranspUF                   : string;
    TranspVolqVol, TranspVolesp, TranspVolMarca          : string;
    TranspVolPesoL, TranspVolPesoB                       : string;
    CobrFatnFat, CobrFatvOrig, CobrFatvDesc, CobrFatvLiq: string;
    PagtPag, PagvPag, PagvTroco                         : string;
    InfCpl, InfAdFisco                                   : string;
  end;

function FmtMoeda(const Valor: Double): string;
function ValorStr(const S: string): Double;

implementation

function FmtMoeda(const Valor: Double): string;
begin
  Result := 'R$ ' + FormatFloat('#,##0.00', Valor);
end;

function ValorStr(const S: string): Double;
var
  Tmp: string;
  Cod: Integer;
begin
  Tmp := StringReplace(S, '.', '', [rfReplaceAll]);
  Tmp := StringReplace(Tmp, ',', '.', [rfReplaceAll]);
  Val(Tmp, Result, Cod);
  if Cod <> 0 then Result := 0;
end;

initialization
  DB_PATH := ExtractFilePath(ParamStr(0)) + DB_FILENAME;

end.
