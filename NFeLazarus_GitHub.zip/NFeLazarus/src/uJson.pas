unit uJson;

{$mode objfpc}{$H+}

{
  JSON usando fpjson + jsonparser — nativos no FPC/Lazarus.
  Sem SuperObject necessario.
}

interface

uses uConstantes;

function DadosParaJSON(const Dados: TDadosNFe): string;
procedure JSONParaDados(const JSON: string; out Dados: TDadosNFe);

implementation

uses
  SysUtils, fpjson, jsonparser;

function DadosParaJSON(const Dados: TDadosNFe): string;
var
  O: TJSONObject;
begin
  O := TJSONObject.Create;
  try
    O.Add('chave_acesso', Dados.ChaveAcesso);
    O.Add('ide_natOp',    Dados.NatOp);
    O.Add('ide_refNFe',   Dados.RefNFe);
    O.Add('prod_CFOP',    Dados.CFOP);
    O.Add('ide_serie',    Dados.Serie);
    O.Add('ide_nNF',      Dados.NumNF);
    O.Add('ide_dhEmi',    Dados.DhEmi);
    O.Add('ide_dhSaiEnt', Dados.DhSaiEnt);
    O.Add('ide_tpNF',     Dados.TpNF);
    O.Add('ide_finNFe',   Dados.FinNFe);
    O.Add('ide_cUF',      Dados.CUF);
    O.Add('ide_idDest',   Dados.IdDest);
    O.Add('ide_indFinal', Dados.IndFinal);

    O.Add('emit_CNPJ',        Dados.EmitCNPJ);
    O.Add('emit_xNome',       Dados.EmitxNome);
    O.Add('emit_xFant',       Dados.EmitxFant);
    O.Add('emit_IE',          Dados.EmitIE);
    O.Add('emit_CRT',         Dados.EmitCRT);
    O.Add('emit_end_fone',    Dados.EmitFone);
    O.Add('emit_end_xLgr',    Dados.EmitxLgr);
    O.Add('emit_end_nro',     Dados.EmitNro);
    O.Add('emit_end_xMun',    Dados.EmitxMun);
    O.Add('emit_end_UF',      Dados.EmitUF);
    O.Add('emit_end_CEP',     Dados.EmitCEP);

    O.Add('dest_CNPJ',        Dados.DestCNPJ);
    O.Add('dest_xNome',       Dados.DestxNome);
    O.Add('dest_email',       Dados.DestEmail);
    O.Add('dest_IE',          Dados.DestIE);
    O.Add('dest_end_xMun',    Dados.DestxMun);
    O.Add('dest_end_UF',      Dados.DestUF);
    O.Add('dest_end_CEP',     Dados.DestCEP);

    O.Add('prod_cProd',   Dados.ProdcProd);
    O.Add('prod_xProd',   Dados.ProdxProd);
    O.Add('prod_NCM',     Dados.ProdNCM);
    O.Add('prod_qCom',    Dados.ProdqCom);
    O.Add('prod_vUnCom',  Dados.ProdvUnCom);
    O.Add('prod_vProd',   Dados.ProdvProd);
    O.Add('prod_vFrete',  Dados.ProdvFrete);
    O.Add('prod_vDesc',   Dados.ProdvDesc);

    O.Add('icms_orig',    Dados.IcmsOrig);
    O.Add('icms_CST',     Dados.IcmsCST);
    O.Add('icms_vBC',     Dados.IcmsvBC);
    O.Add('icms_pICMS',   Dados.IcmspICMS);
    O.Add('icms_vICMS',   Dados.IcmsvICMS);

    O.Add('rt_pCBS', Dados.RtpCBS);
    O.Add('rt_vCBS', Dados.RtvCBS);
    O.Add('rt_pIBS', Dados.RtpIBS);
    O.Add('rt_vIBS', Dados.RtvIBS);

    O.Add('ipi_CST',  Dados.IpiCST);
    O.Add('ipi_pIPI', Dados.IpipIPI);
    O.Add('ipi_vIPI', Dados.IpivIPI);

    O.Add('pis_CST',        Dados.PisCST);
    O.Add('pis_pPIS',       Dados.PispPIS);
    O.Add('pis_vPIS',       Dados.PisvPIS);
    O.Add('cofins_CST',     Dados.CofinsCST);
    O.Add('cofins_pCOFINS', Dados.CofinspCOFINS);
    O.Add('cofins_vCOFINS', Dados.CofinsvCOFINS);

    O.Add('total_vNF',       Dados.TotalvNF);
    O.Add('total_vICMS',     Dados.TotalvICMS);
    O.Add('total_vPIS',      Dados.TotalvPIS);
    O.Add('total_vCOFINS',   Dados.TotalvCOFINS);
    O.Add('total_vTotTrib',  Dados.TotalvTotTrib);

    O.Add('transp_modFrete', Dados.TranspModFrete);
    O.Add('pag_tPag',        Dados.PagtPag);
    O.Add('pag_vPag',        Dados.PagvPag);
    O.Add('infAdic_infCpl',  Dados.InfCpl);
    O.Add('infAdic_infAdFisco', Dados.InfAdFisco);

    Result := O.FormatJSON;
  finally
    O.Free;
  end;
end;

procedure JSONParaDados(const JSON: string; out Dados: TDadosNFe);
var
  O: TJSONObject;

  function S(const Key: string): string;
  var D: TJSONData;
  begin
    D := O.Find(Key);
    if D <> nil then Result := D.AsString else Result := '';
  end;

begin
  FillChar(Dados, SizeOf(Dados), 0);
  if JSON = '' then Exit;
  O := TJSONObject(GetJSON(JSON));
  if O = nil then Exit;
  try
    Dados.ChaveAcesso := S('chave_acesso');
    Dados.NatOp       := S('ide_natOp');
    Dados.RefNFe      := S('ide_refNFe');
    Dados.CFOP        := S('prod_CFOP');
    Dados.Serie       := S('ide_serie');
    Dados.NumNF       := S('ide_nNF');
    Dados.DhEmi       := S('ide_dhEmi');
    Dados.TpNF        := S('ide_tpNF');
    Dados.FinNFe      := S('ide_finNFe');
    Dados.EmitCNPJ    := S('emit_CNPJ');
    Dados.EmitxNome   := S('emit_xNome');
    Dados.EmitIE      := S('emit_IE');
    Dados.EmitxLgr    := S('emit_end_xLgr');
    Dados.EmitUF      := S('emit_end_UF');
    Dados.DestCNPJ    := S('dest_CNPJ');
    Dados.DestxNome   := S('dest_xNome');
    Dados.DestUF      := S('dest_end_UF');
    Dados.ProdcProd   := S('prod_cProd');
    Dados.ProdxProd   := S('prod_xProd');
    Dados.ProdNCM     := S('prod_NCM');
    Dados.ProdvProd   := S('prod_vProd');
    Dados.IcmsOrig    := S('icms_orig');
    Dados.IcmsCST     := S('icms_CST');
    Dados.IcmsvICMS   := S('icms_vICMS');
    Dados.RtpCBS      := S('rt_pCBS');
    Dados.RtpIBS      := S('rt_pIBS');
    Dados.PisCST      := S('pis_CST');
    Dados.PisvPIS     := S('pis_vPIS');
    Dados.CofinsCST   := S('cofins_CST');
    Dados.CofinsvCOFINS := S('cofins_vCOFINS');
    Dados.TotalvNF    := S('total_vNF');
    Dados.TotalvTotTrib := S('total_vTotTrib');
    Dados.TranspModFrete := S('transp_modFrete');
    Dados.PagtPag     := S('pag_tPag');
    Dados.PagvPag     := S('pag_vPag');
    Dados.InfCpl      := S('infAdic_infCpl');
    Dados.InfAdFisco  := S('infAdic_infAdFisco');
  finally
    O.Free;
  end;
end;

end.
