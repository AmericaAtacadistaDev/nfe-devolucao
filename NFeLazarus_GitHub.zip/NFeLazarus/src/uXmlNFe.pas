unit uXmlNFe;

{$mode objfpc}{$H+}

interface

uses uConstantes;

function ParseXmlNFe(const Arquivo: string; out Dados: TDadosNFe): Boolean;

implementation

uses
  SysUtils, DOM, XMLRead;

const
  NS = 'http://www.portalfiscal.inf.br/nfe';

function GetText(Node: TDOMNode; const Tag: string): string;
var
  List : TDOMNodeList;
  Child: TDOMNode;
  I    : Integer;
begin
  Result := '';
  if Node = nil then Exit;

  // Tenta filho direto com namespace
  List := TDOMElement(Node).GetElementsByTagNameNS(DOMString(NS), DOMString(Tag));
  if (List <> nil) and (List.Count > 0) then
  begin
    Child := List[0].FirstChild;
    if Child <> nil then Result := Trim(string(Child.NodeValue));
    List.Free;
    Exit;
  end;

  // Fallback: sem namespace
  List := TDOMElement(Node).GetElementsByTagName(DOMString(Tag));
  if (List <> nil) and (List.Count > 0) then
  begin
    Child := List[0].FirstChild;
    if Child <> nil then Result := Trim(string(Child.NodeValue));
  end;
  if List <> nil then List.Free;
end;

function FindNode(Root: TDOMNode; const Tag: string): TDOMNode;
var
  List: TDOMNodeList;
begin
  Result := nil;
  if Root = nil then Exit;
  List := TDOMElement(Root).GetElementsByTagNameNS(DOMString(NS), DOMString(Tag));
  if (List <> nil) and (List.Count > 0) then Result := List[0];
  if List <> nil then List.Free;
  if Result <> nil then Exit;
  // Fallback sem NS
  List := TDOMElement(Root).GetElementsByTagName(DOMString(Tag));
  if (List <> nil) and (List.Count > 0) then Result := List[0];
  if List <> nil then List.Free;
end;

function ParseXmlNFe(const Arquivo: string; out Dados: TDadosNFe): Boolean;
var
  Doc   : TXMLDocument;
  Root  : TDOMNode;
  Ide, Emit, Dest, Det, Prod : TDOMNode;
  Imp, ICMSGr, ICMS, IPI     : TDOMNode;
  IPIGr, PIS, COFINS          : TDOMNode;
  Tot, Transp, Cobr, Pag      : TDOMNode;
  InfNFe, InfAdic             : TDOMNode;
  Attr  : TDOMAttr;
  List  : TDOMNodeList;

  function G(Node: TDOMNode; const Tag: string): string;
  begin
    Result := GetText(Node, Tag);
  end;

begin
  Result := False;
  FillChar(Dados, SizeOf(Dados), 0);
  Doc := nil;
  try
    ReadXMLFile(Doc, Arquivo);
    Root := Doc.DocumentElement;

    // Chave de acesso
    InfNFe := FindNode(Root, 'infNFe');
    if InfNFe <> nil then
    begin
      Attr := TDOMElement(InfNFe).GetAttributeNode('Id');
      if Attr <> nil then
      begin
        Dados.ChaveAcesso := string(Attr.Value);
        if Copy(Dados.ChaveAcesso, 1, 3) = 'NFe' then
          Dados.ChaveAcesso := Copy(Dados.ChaveAcesso, 4, 999);
      end;
    end;

    // Identificacao
    Ide := FindNode(Root, 'ide');
    Dados.NatOp    := G(Ide, 'natOp');
    Dados.Serie    := G(Ide, 'serie');
    Dados.NumNF    := G(Ide, 'nNF');
    Dados.DhEmi    := G(Ide, 'dhEmi');
    Dados.DhSaiEnt := G(Ide, 'dhSaiEnt');
    Dados.TpNF     := G(Ide, 'tpNF');
    Dados.FinNFe   := G(Ide, 'finNFe');
    Dados.CUF      := G(Ide, 'cUF');
    Dados.IdDest   := G(Ide, 'idDest');
    Dados.IndFinal := G(Ide, 'indFinal');

    // Emitente
    Emit := FindNode(Root, 'emit');
    Dados.EmitCNPJ    := G(Emit, 'CNPJ');
    Dados.EmitxNome   := G(Emit, 'xNome');
    Dados.EmitxFant   := G(Emit, 'xFant');
    Dados.EmitIE      := G(Emit, 'IE');
    Dados.EmitCRT     := G(Emit, 'CRT');
    Dados.EmitFone    := G(FindNode(Emit, 'enderEmit'), 'fone');
    Dados.EmitxLgr    := G(FindNode(Emit, 'enderEmit'), 'xLgr');
    Dados.EmitNro     := G(FindNode(Emit, 'enderEmit'), 'nro');
    Dados.EmitxMun    := G(FindNode(Emit, 'enderEmit'), 'xMun');
    Dados.EmitUF      := G(FindNode(Emit, 'enderEmit'), 'UF');
    Dados.EmitCEP     := G(FindNode(Emit, 'enderEmit'), 'CEP');

    // Destinatario
    Dest := FindNode(Root, 'dest');
    Dados.DestCNPJ    := G(Dest, 'CNPJ');
    if Dados.DestCNPJ = '' then Dados.DestCNPJ := G(Dest, 'CPF');
    Dados.DestxNome   := G(Dest, 'xNome');
    Dados.DestEmail   := G(Dest, 'email');
    Dados.DestIE      := G(Dest, 'IE');
    Dados.DestxLgr    := G(FindNode(Dest, 'enderDest'), 'xLgr');
    Dados.DestNro     := G(FindNode(Dest, 'enderDest'), 'nro');
    Dados.DestxMun    := G(FindNode(Dest, 'enderDest'), 'xMun');
    Dados.DestUF      := G(FindNode(Dest, 'enderDest'), 'UF');
    Dados.DestCEP     := G(FindNode(Dest, 'enderDest'), 'CEP');

    // Produto (primeiro det)
    List := TDOMElement(Root).GetElementsByTagNameNS(DOMString(NS), 'det');
    if (List = nil) or (List.Count = 0) then
      List := TDOMElement(Root).GetElementsByTagName('det');
    if (List <> nil) and (List.Count > 0) then
    begin
      Det  := List[0];
      Prod := FindNode(Det, 'prod');
      Dados.ProdcProd  := G(Prod, 'cProd');
      Dados.ProdcEAN   := G(Prod, 'cEAN');
      Dados.ProdxProd  := G(Prod, 'xProd');
      Dados.ProdNCM    := G(Prod, 'NCM');
      Dados.CFOP       := G(Prod, 'CFOP');
      Dados.ProduCom   := G(Prod, 'uCom');
      Dados.ProdqCom   := G(Prod, 'qCom');
      Dados.ProdvUnCom := G(Prod, 'vUnCom');
      Dados.ProdvProd  := G(Prod, 'vProd');
      Dados.ProdvFrete := G(Prod, 'vFrete');
      Dados.ProdvDesc  := G(Prod, 'vDesc');

      Imp    := FindNode(Det, 'imposto');
      ICMSGr := FindNode(Imp, 'ICMS');
      if ICMSGr <> nil then
      begin
        ICMS := ICMSGr.FirstChild;
        if ICMS <> nil then
        begin
          Dados.IcmsOrig  := G(ICMS, 'orig');
          Dados.IcmsCST   := G(ICMS, 'CST');
          Dados.IcmsvBC   := G(ICMS, 'vBC');
          Dados.IcmspICMS := G(ICMS, 'pICMS');
          Dados.IcmsvICMS := G(ICMS, 'vICMS');
        end;
      end;

      IPIGr := FindNode(Imp, 'IPI');
      if IPIGr <> nil then
      begin
        IPI := FindNode(IPIGr, 'IPITrib');
        Dados.IpiCST  := G(IPI, 'CST');
        Dados.IpipIPI := G(IPI, 'pIPI');
        Dados.IpivIPI := G(IPI, 'vIPI');
      end;

      PIS := FindNode(FindNode(Imp,'PIS'), 'PISAliq');
      Dados.PisCST  := G(PIS, 'CST');
      Dados.PispPIS := G(PIS, 'pPIS');
      Dados.PisvPIS := G(PIS, 'vPIS');

      COFINS := FindNode(FindNode(Imp,'COFINS'), 'COFINSAliq');
      Dados.CofinsCST       := G(COFINS, 'CST');
      Dados.CofinspCOFINS   := G(COFINS, 'pCOFINS');
      Dados.CofinsvCOFINS   := G(COFINS, 'vCOFINS');
    end;
    if List <> nil then List.Free;

    // Totais
    Tot := FindNode(Root, 'ICMSTot');
    Dados.TotalvBC      := G(Tot, 'vBC');
    Dados.TotalvICMS    := G(Tot, 'vICMS');
    Dados.TotalvProd    := G(Tot, 'vProd');
    Dados.TotalvFrete   := G(Tot, 'vFrete');
    Dados.TotalvDesc    := G(Tot, 'vDesc');
    Dados.TotalvIPI     := G(Tot, 'vIPI');
    Dados.TotalvPIS     := G(Tot, 'vPIS');
    Dados.TotalvCOFINS  := G(Tot, 'vCOFINS');
    Dados.TotalvNF      := G(Tot, 'vNF');
    Dados.TotalvTotTrib := G(Tot, 'vTotTrib');

    // Transporte
    Transp := FindNode(Root, 'transp');
    Dados.TranspModFrete := G(Transp, 'modFrete');
    Dados.TranspxNome    := G(FindNode(Transp,'transporta'), 'xNome');
    Dados.TranspUF       := G(FindNode(Transp,'transporta'), 'UF');
    Dados.TranspVolPesoB := G(FindNode(Transp,'vol'), 'pesoB');

    // Pagamento
    Pag := FindNode(Root, 'pag');
    Dados.PagtPag := G(FindNode(Pag,'detPag'), 'tPag');
    Dados.PagvPag := G(FindNode(Pag,'detPag'), 'vPag');

    // Inf. Adicionais
    InfAdic := FindNode(Root, 'infAdic');
    Dados.InfCpl     := G(InfAdic, 'infCpl');
    Dados.InfAdFisco := G(InfAdic, 'infAdFisco');

    Result := True;
  except
    on E: Exception do
      raise Exception.Create('Erro ao ler XML: ' + E.Message);
  end;
  if Doc <> nil then Doc.Free;
end;

end.
