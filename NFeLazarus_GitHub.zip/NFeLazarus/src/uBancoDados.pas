unit uBancoDados;

{$mode objfpc}{$H+}

{
  Acesso ao SQLite3 usando a unit sqlite3 nativa do FPC
  (pacote lazarus sqlite3 / fpc sqlite3dyn)
  Sem ZeosLib necessario — FPC tem suporte nativo a SQLite.
}

interface

uses
  SysUtils, sqlite3dyn, sqlite3,
  uConstantes, uSeguranca;

// Inicializacao
procedure InitDB;
function  TemUsuarios: Boolean;

// Usuarios
function  CriarUsuario(const Nome, Login, Senha, Perfil: string): Boolean;
function  Autenticar(const Login, Senha: string): TUsuario;
function  AlterarSenha(const Login, SenhaNova: string): Boolean;
procedure DesativarUsuario(ID: Integer);
procedure ReativarUsuario(ID: Integer);
function  ListarUsuariosSQL: string;  // retorna JSON array simples

// Notas
function  SalvarNota(const Dados: TDadosNFe; const DadosJSON: string): Integer;
procedure AtualizarStatus(IDNota: Integer; const Status: string);
function  BuscarNotasSQL(const Filtro: string): string; // JSON array
function  CarregarNotaJSON(IDNota: Integer): string;

implementation

uses
  Classes;

var
  DB: psqlite3 = nil;

// ── Helpers internos ──────────────────────────────────────────────────────────
function EscSQL(const S: string): string;
begin
  Result := StringReplace(S, '''', '''''', [rfReplaceAll]);
end;

procedure ExecSQL(const SQL: string);
var
  ErrMsg: PChar;
  Ret   : Integer;
begin
  ErrMsg := nil;
  Ret := sqlite3_exec(DB, PChar(SQL), nil, nil, @ErrMsg);
  if Ret <> SQLITE_OK then
  begin
    // Libera mem e ignora silenciosamente erros nao criticos
    if ErrMsg <> nil then sqlite3_free(ErrMsg);
  end;
end;

function QueryInt(const SQL: string): Int64;
var
  Stmt: psqlite3_stmt;
begin
  Result := 0;
  if sqlite3_prepare_v2(DB, PChar(SQL), -1, @Stmt, nil) = SQLITE_OK then
  begin
    if sqlite3_step(Stmt) = SQLITE_ROW then
      Result := sqlite3_column_int64(Stmt, 0);
    sqlite3_finalize(Stmt);
  end;
end;

function QueryStr(const SQL: string): string;
var
  Stmt: psqlite3_stmt;
  P   : PChar;
begin
  Result := '';
  if sqlite3_prepare_v2(DB, PChar(SQL), -1, @Stmt, nil) = SQLITE_OK then
  begin
    if sqlite3_step(Stmt) = SQLITE_ROW then
    begin
      P := sqlite3_column_text(Stmt, 0);
      if P <> nil then Result := string(P);
    end;
    sqlite3_finalize(Stmt);
  end;
end;

// ── Conexao e criacao de tabelas ──────────────────────────────────────────────
procedure ConectarBanco;
begin
  if DB <> nil then Exit;
  if sqlite3_open(PChar(DB_PATH), @DB) <> SQLITE_OK then
    raise Exception.Create('Nao foi possivel abrir o banco: ' + DB_PATH);
  // Ativar WAL para melhor performance
  ExecSQL('PRAGMA journal_mode=WAL;');
  ExecSQL('PRAGMA foreign_keys=ON;');
end;

procedure InitDB;
begin
  ConectarBanco;

  ExecSQL(
    'CREATE TABLE IF NOT EXISTS notas_devolucao (' +
    ' id                 INTEGER PRIMARY KEY AUTOINCREMENT,' +
    ' numero_nf          TEXT,' +
    ' chave_acesso       TEXT,' +
    ' data_emissao       TEXT,' +
    ' emitente_cnpj      TEXT,' +
    ' emitente_razao     TEXT,' +
    ' destinatario_cnpj  TEXT,' +
    ' destinatario_razao TEXT,' +
    ' valor_total        REAL,' +
    ' status             TEXT DEFAULT ''Registrada'',' +
    ' motivo             TEXT,' +
    ' data_registro      TEXT,' +
    ' dados_json         TEXT' +
    ');'
  );

  ExecSQL(
    'CREATE TABLE IF NOT EXISTS usuarios (' +
    ' id            INTEGER PRIMARY KEY AUTOINCREMENT,' +
    ' nome          TEXT NOT NULL,' +
    ' login         TEXT NOT NULL UNIQUE,' +
    ' senha_hash    TEXT NOT NULL,' +
    ' salt          TEXT NOT NULL,' +
    ' perfil        TEXT DEFAULT ''operador'',' +
    ' ativo         INTEGER DEFAULT 1,' +
    ' ultimo_acesso TEXT,' +
    ' data_criacao  TEXT' +
    ');'
  );
end;

// ── Usuarios ──────────────────────────────────────────────────────────────────
function TemUsuarios: Boolean;
begin
  try
    ConectarBanco;
    Result := QueryInt('SELECT COUNT(*) FROM usuarios WHERE ativo=1') > 0;
  except
    Result := False;
  end;
end;

function CriarUsuario(const Nome, Login, Senha, Perfil: string): Boolean;
var
  Salt, Hash, SQL: string;
  ErrMsg: PChar;
begin
  Result := False;
  try
    ConectarBanco;
    Salt := GerarSalt;
    Hash := HashSenhaSHA256(Salt + Senha);
    SQL  :=
      'INSERT INTO usuarios (nome,login,senha_hash,salt,perfil,ativo,data_criacao) ' +
      'VALUES (''' + EscSQL(Nome)   + ''',''' +
                     EscSQL(Login)  + ''',''' +
                     Hash           + ''',''' +
                     Salt           + ''',''' +
                     EscSQL(Perfil) + ''',1,''' +
      FormatDateTime('dd/mm/yyyy hh:nn:ss', Now) + ''');';
    ErrMsg := nil;
    Result := sqlite3_exec(DB, PChar(SQL), nil, nil, @ErrMsg) = SQLITE_OK;
    if ErrMsg <> nil then sqlite3_free(ErrMsg);
  except
    Result := False;
  end;
end;

function Autenticar(const Login, Senha: string): TUsuario;
var
  Stmt      : psqlite3_stmt;
  SQL       : string;
  HashArm   : string;
  SaltArm   : string;
  HashCalc  : string;
  P         : PChar;
begin
  Result.ID    := -1;
  Result.Nome  := '';
  Result.Login := '';
  Result.Perfil := puOperador;
  Result.Ativo  := False;

  try
    ConectarBanco;
    SQL := 'SELECT id,nome,login,senha_hash,salt,perfil FROM usuarios ' +
           'WHERE login=''' + EscSQL(Login) + ''' AND ativo=1 LIMIT 1;';

    if sqlite3_prepare_v2(DB, PChar(SQL), -1, @Stmt, nil) = SQLITE_OK then
    begin
      if sqlite3_step(Stmt) = SQLITE_ROW then
      begin
        P := sqlite3_column_text(Stmt, 3);
        if P <> nil then HashArm := string(P);
        P := sqlite3_column_text(Stmt, 4);
        if P <> nil then SaltArm := string(P);

        HashCalc := HashSenhaSHA256(SaltArm + Senha);

        if HashCalc = HashArm then
        begin
          Result.ID    := sqlite3_column_int(Stmt, 0);
          P := sqlite3_column_text(Stmt, 1);
          if P <> nil then Result.Nome := string(P);
          P := sqlite3_column_text(Stmt, 2);
          if P <> nil then Result.Login := string(P);
          P := sqlite3_column_text(Stmt, 5);
          if (P <> nil) and (string(P) = 'admin') then
            Result.Perfil := puAdmin;
          Result.Ativo := True;
          sqlite3_finalize(Stmt);

          // Atualiza ultimo acesso
          ExecSQL(
            'UPDATE usuarios SET ultimo_acesso=''' +
            FormatDateTime('dd/mm/yyyy hh:nn:ss', Now) +
            ''' WHERE id=' + IntToStr(Result.ID) + ';'
          );
          Exit;
        end;
      end;
      sqlite3_finalize(Stmt);
    end;
  except
    // retorna vazio
  end;
end;

function AlterarSenha(const Login, SenhaNova: string): Boolean;
var
  Salt, Hash, SQL: string;
  ErrMsg: PChar;
begin
  Salt := GerarSalt;
  Hash := HashSenhaSHA256(Salt + SenhaNova);
  SQL  := 'UPDATE usuarios SET senha_hash=''' + Hash + ''',salt=''' + Salt +
          ''' WHERE login=''' + EscSQL(Login) + ''';';
  ErrMsg := nil;
  Result := sqlite3_exec(DB, PChar(SQL), nil, nil, @ErrMsg) = SQLITE_OK;
  if ErrMsg <> nil then sqlite3_free(ErrMsg);
end;

procedure DesativarUsuario(ID: Integer);
begin
  ExecSQL('UPDATE usuarios SET ativo=0 WHERE id=' + IntToStr(ID) + ';');
end;

procedure ReativarUsuario(ID: Integer);
begin
  ExecSQL('UPDATE usuarios SET ativo=1 WHERE id=' + IntToStr(ID) + ';');
end;

function ListarUsuariosSQL: string;
var
  Stmt: psqlite3_stmt;
  SQL : string;
  SB  : TStringList;
  P   : PChar;
  function Col(I: Integer): string;
  begin
    P := sqlite3_column_text(Stmt, I);
    if P <> nil then Result := string(P) else Result := '';
  end;
begin
  Result := '';
  SB := TStringList.Create;
  try
    SQL := 'SELECT id,nome,login,perfil,ativo,ultimo_acesso,data_criacao FROM usuarios ORDER BY id;';
    if sqlite3_prepare_v2(DB, PChar(SQL), -1, @Stmt, nil) = SQLITE_OK then
    begin
      while sqlite3_step(Stmt) = SQLITE_ROW do
        SB.Add(
          IntToStr(sqlite3_column_int(Stmt,0)) + '|' +
          Col(1) + '|' + Col(2) + '|' + Col(3) + '|' +
          IntToStr(sqlite3_column_int(Stmt,4)) + '|' +
          Col(5) + '|' + Col(6)
        );
      sqlite3_finalize(Stmt);
    end;
    Result := SB.Text;
  finally
    SB.Free;
  end;
end;

// ── Notas ─────────────────────────────────────────────────────────────────────
function SalvarNota(const Dados: TDadosNFe; const DadosJSON: string): Integer;
var
  SQL   : string;
  ErrMsg: PChar;
begin
  SQL :=
    'INSERT INTO notas_devolucao ' +
    '(numero_nf,chave_acesso,data_emissao,emitente_cnpj,emitente_razao,' +
    ' destinatario_cnpj,destinatario_razao,valor_total,status,motivo,' +
    ' data_registro,dados_json) VALUES (' +
    '''' + EscSQL(Dados.NumNF)      + ''',' +
    '''' + EscSQL(Dados.ChaveAcesso)+ ''',' +
    '''' + EscSQL(Dados.DhEmi)      + ''',' +
    '''' + EscSQL(Dados.EmitCNPJ)   + ''',' +
    '''' + EscSQL(Dados.EmitxNome)  + ''',' +
    '''' + EscSQL(Dados.DestCNPJ)   + ''',' +
    '''' + EscSQL(Dados.DestxNome)  + ''',' +
    FloatToStr(ValorStr(Dados.TotalvNF)) + ',' +
    '''' + STATUS_REGISTRADA        + ''',' +
    '''' + EscSQL(Dados.InfCpl)     + ''',' +
    '''' + FormatDateTime('dd/mm/yyyy hh:nn:ss', Now) + ''',' +
    '''' + EscSQL(DadosJSON)        + '''' +
    ');';

  ErrMsg := nil;
  if sqlite3_exec(DB, PChar(SQL), nil, nil, @ErrMsg) = SQLITE_OK then
    Result := QueryInt('SELECT last_insert_rowid();')
  else
  begin
    if ErrMsg <> nil then sqlite3_free(ErrMsg);
    Result := -1;
  end;
end;

procedure AtualizarStatus(IDNota: Integer; const Status: string);
begin
  ExecSQL(
    'UPDATE notas_devolucao SET status=''' + EscSQL(Status) +
    ''' WHERE id=' + IntToStr(IDNota) + ';'
  );
end;

function BuscarNotasSQL(const Filtro: string): string;
var
  Stmt: psqlite3_stmt;
  SQL : string;
  SB  : TStringList;
  P   : PChar;
  function Col(I: Integer): string;
  begin
    P := sqlite3_column_text(Stmt, I);
    if P <> nil then Result := string(P) else Result := '';
  end;
begin
  if Filtro = '' then
    SQL :=
      'SELECT id,numero_nf,data_emissao,emitente_razao,destinatario_razao,' +
      '       valor_total,status,data_registro FROM notas_devolucao ORDER BY id DESC;'
  else
    SQL :=
      'SELECT id,numero_nf,data_emissao,emitente_razao,destinatario_razao,' +
      '       valor_total,status,data_registro FROM notas_devolucao ' +
      'WHERE emitente_razao LIKE ''%' + EscSQL(Filtro) + '%'' ' +
      '   OR destinatario_razao LIKE ''%' + EscSQL(Filtro) + '%'' ' +
      '   OR numero_nf LIKE ''%' + EscSQL(Filtro) + '%'' ' +
      'ORDER BY id DESC;';

  SB := TStringList.Create;
  try
    if sqlite3_prepare_v2(DB, PChar(SQL), -1, @Stmt, nil) = SQLITE_OK then
    begin
      while sqlite3_step(Stmt) = SQLITE_ROW do
        SB.Add(
          IntToStr(sqlite3_column_int(Stmt,0)) + '|' +
          Col(1) + '|' + Col(2) + '|' + Col(3) + '|' + Col(4) + '|' +
          Col(5) + '|' + Col(6) + '|' + Col(7)
        );
      sqlite3_finalize(Stmt);
    end;
    Result := SB.Text;
  finally
    SB.Free;
  end;
end;

function CarregarNotaJSON(IDNota: Integer): string;
begin
  ConectarBanco;
  Result := QueryStr(
    'SELECT dados_json FROM notas_devolucao WHERE id=' + IntToStr(IDNota) + ';'
  );
  if Result = '' then Result := '{}';
end;

finalization
  if DB <> nil then
  begin
    sqlite3_close(DB);
    DB := nil;
  end;

end.
