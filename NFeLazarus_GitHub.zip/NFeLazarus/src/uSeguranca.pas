unit uSeguranca;

{$mode objfpc}{$H+}

{
  SHA-256 usando a unit SHA2 nativa do Free Pascal (fpc-utils)
  Sem dependencia de DCPcrypt — FPC ja inclui SHA2 nativamente.
  Unit: SHA2  (pacote: fpc-utils, incluido no FPC 3.x)
}

interface

function GerarSalt: string;
function HashSenhaSHA256(const Texto: string): string;
function ValidarForcaSenha(const Senha: string): Integer;

implementation

uses
  SysUtils, SHA2;

function GerarSalt: string;
var
  I: Integer;
  B: Byte;
begin
  Result := '';
  Randomize;
  for I := 1 to 16 do
  begin
    B := Random(256);
    Result := Result + IntToHex(B, 2);
  end;
  Result := LowerCase(Result);
end;

function HashSenhaSHA256(const Texto: string): string;
var
  Digest: TSHA256Digest;
  I: Integer;
begin
  Digest := SHA256String(Texto);
  Result := '';
  for I := 0 to 31 do
    Result := Result + IntToHex(Digest[I], 2);
  Result := LowerCase(Result);
end;

function ValidarForcaSenha(const Senha: string): Integer;
var
  I: Integer;
  C: Char;
  TemMaiusc, TemDigito, TemEspecial: Boolean;
begin
  Result      := 0;
  TemMaiusc   := False;
  TemDigito   := False;
  TemEspecial := False;
  for I := 1 to Length(Senha) do
  begin
    C := Senha[I];
    if C in ['A'..'Z'] then TemMaiusc := True;
    if C in ['0'..'9'] then TemDigito := True;
    if C in ['!','@','#','$','%','^','&','*','_','-','=','+'] then
      TemEspecial := True;
  end;
  if Length(Senha) >= 6  then Inc(Result);
  if Length(Senha) >= 10 then Inc(Result);
  if TemMaiusc           then Inc(Result);
  if TemDigito           then Inc(Result);
  if TemEspecial         then Inc(Result);
end;

end.
