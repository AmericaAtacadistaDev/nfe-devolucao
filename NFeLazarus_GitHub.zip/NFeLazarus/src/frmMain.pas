unit frmMain;

{$mode objfpc}{$H+}

interface

uses
  SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, ExtCtrls, ComCtrls, Grids,
  uConstantes, uBancoDados, uXmlNFe, uJson;

type
  TfMain = class(TForm)
  private
    FUsuario : TUsuario;

    // Layout
    pnlHeader  : TPanel;
    pnlFooter  : TPanel;
    pgc        : TPageControl;
    tabNova    : TTabSheet;
    tabReg     : TTabSheet;
    tabCalc    : TTabSheet;

    // Header
    lblTitulo      : TLabel;
    lblUsuario     : TLabel;
    btnSair        : TBitBtn;
    btnUsuarios    : TBitBtn;

    // Footer
    lblFooter      : TLabel;
    btnFooterSair  : TBitBtn;
    btnAlterarSenha: TBitBtn;

    // ── Aba Nova (campos do formulario) ───────────────────────────────────
    scb: TScrollBox;
    // Identificacao
    edtNatOp, edtRefNFe, edtCFOP, edtSerie, edtNumNF: TEdit;
    edtDhEmi, edtDhSaiEnt, edtTpNF, edtFinNFe       : TEdit;
    // Emitente
    edtEmitCNPJ, edtEmitxNome, edtEmitIE, edtEmitCRT: TEdit;
    edtEmitxLgr, edtEmitNro, edtEmitxMun             : TEdit;
    edtEmitUF, edtEmitCEP                            : TEdit;
    // Destinatario
    edtDestCNPJ, edtDestxNome, edtDestEmail          : TEdit;
    edtDestxLgr, edtDestNro, edtDestxMun             : TEdit;
    edtDestUF, edtDestCEP                            : TEdit;
    // Produto
    edtProdcProd, edtProdxProd, edtProdNCM, edtCFOPprod: TEdit;
    edtProduCom, edtProdqCom, edtProdvUnCom, edtProdvProd: TEdit;
    edtProdvFrete, edtProdvDesc                      : TEdit;
    // ICMS
    edtIcmsOrig, edtIcmsCST, edtIcmsvBC              : TEdit;
    edtIcmspICMS, edtIcmsvICMS                       : TEdit;
    // Reforma Tributaria
    edtRtpCBS, edtRtvCBS, edtRtpIBS, edtRtvIBS      : TEdit;
    // IPI
    edtIpiCST, edtIpipIPI, edtIpivIPI               : TEdit;
    // PIS / COFINS
    edtPisCST, edtPispPIS, edtPisvPIS               : TEdit;
    edtCofinsCST, edtCofinspCOFINS, edtCofinsvCOFINS: TEdit;
    // Totais
    edtTotalvProd, edtTotalvICMS, edtTotalvPIS       : TEdit;
    edtTotalvCOFINS, edtTotalvNF, edtTotalvTotTrib   : TEdit;
    // Transporte
    edtTranspModFrete, edtTranspxNome, edtTranspUF   : TEdit;
    // Pagamento
    edtPagtPag, edtPagvPag                           : TEdit;
    // Info adicionais
    mmoInfCpl, mmoInfAdFisco                         : TMemo;

    // ── Aba Registro ──────────────────────────────────────────────────────
    edtBusca   : TEdit;
    sgNotas    : TStringGrid;

    // ── Aba Calculadora ───────────────────────────────────────────────────
    edtCvProd, edtCpICMS, edtCpIPI, edtCpPIS        : TEdit;
    edtCpCOFINS, edtCpCBS, edtCpIBS                 : TEdit;
    edtCpDesc, edtCpFrete                            : TEdit;
    lblRvICMS, lblRvIPI, lblRvPIS, lblRvCOFINS       : TLabel;
    lblRvCBS, lblRvIBS, lblRvDesc, lblRvFrete        : TLabel;
    lblRvTotal, lblRvTrib                            : TLabel;

    procedure ConstruirUI;
    procedure ConstruirHeader;
    procedure ConstruirFooter;
    procedure ConstruirTabNova;
    procedure ConstruirTabRegistro;
    procedure ConstruirTabCalc;
    procedure AdicionarSecao(const Titulo: string; Campos: array of string;
                             var Edts: array of TEdit);

    // Acoes
    procedure AcaoImportarXML(Sender: TObject);
    procedure AcaoSalvarNota(Sender: TObject);
    procedure AcaoLimpar(Sender: TObject);
    procedure AcaoExportarJSON(Sender: TObject);
    procedure AcaoCalcular(Sender: TObject);
    procedure AcaoBuscar(Sender: TObject);
    procedure AcaoMudarStatus(const S: string);
    procedure AcaoCarregarEditar(Sender: TObject);
    procedure AcaoLogout(Sender: TObject);
    procedure AcaoAlterarSenha(Sender: TObject);
    procedure AcaoUsuarios(Sender: TObject);
    procedure DoKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);

    function  ObterDados: TDadosNFe;
    procedure PreencherForm(const D: TDadosNFe);
    procedure LimparForm;
    procedure CarregarRegistros;
  public
    procedure Inicializar(const AUsuario: TUsuario);
  end;

var
  fMain: TfMain;

implementation

uses
  frmLogin;

{$R *.lfm}

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS UI
// ─────────────────────────────────────────────────────────────────────────────
function NovoEdit(Parent: TWinControl; const Val: string = ''): TEdit;
begin
  Result := TEdit.Create(Parent.Owner);
  Result.Parent     := Parent;
  Result.Text       := Val;
  Result.Color      := COR_BG_FIELD;
  Result.Font.Color := COR_TEXT;
  Result.Height     := 24;
end;

function NovoLbl(Parent: TWinControl; const Cap: string): TLabel;
begin
  Result := TLabel.Create(Parent.Owner);
  Result.Parent     := Parent;
  Result.Caption    := Cap;
  Result.Font.Color := COR_TEXT_MUTED;
end;

function NovoBotao(Parent: TWinControl; const Cap: string;
                   Cor: TColor; W: Integer = 140): TBitBtn;
begin
  Result := TBitBtn.Create(Parent.Owner);
  Result.Parent     := Parent;
  Result.Caption    := Cap;
  Result.Width      := W;
  Result.Height     := 30;
  Result.Color      := Cor;
  Result.Font.Color := clWhite;
  Result.Font.Style := [fsBold];
  Result.Flat       := True;
end;

// ─────────────────────────────────────────────────────────────────────────────
// INICIALIZACAO
// ─────────────────────────────────────────────────────────────────────────────
procedure TfMain.Inicializar(const AUsuario: TUsuario);
begin
  FUsuario := AUsuario;
  Caption  := APP_TITLE + '  —  ' + AUsuario.Nome;

  lblUsuario.Caption :=
    AUsuario.Nome + '  |  ' +
    IfThen(AUsuario.Perfil = puAdmin, 'Administrador', 'Operador');

  btnUsuarios.Visible := (AUsuario.Perfil = puAdmin);

  lblFooter.Caption :=
    'Usuario: ' + AUsuario.Nome +
    '  |  Sessao: ' + FormatDateTime('dd/mm/yyyy hh:nn', Now) +
    '  |  Ctrl+Q para sair';

  CarregarRegistros;
end;

// ─────────────────────────────────────────────────────────────────────────────
// CONSTRUCAO DA UI
// ─────────────────────────────────────────────────────────────────────────────
procedure TfMain.ConstruirUI;
begin
  Caption     := APP_TITLE;
  Width       := 1280; Height := 800;
  Position    := poScreenCenter;
  Color       := COR_BG_DARK;
  KeyPreview  := True;
  OnKeyDown   := @DoKeyDown;

  ConstruirHeader;
  ConstruirFooter;

  pgc := TPageControl.Create(Self);
  pgc.Parent := Self; pgc.Align := alClient;

  tabNova := TTabSheet.Create(pgc); tabNova.PageControl := pgc;
  tabNova.Caption := '  Nova Devolucao  ';
  tabReg  := TTabSheet.Create(pgc); tabReg.PageControl  := pgc;
  tabReg.Caption  := '  Registro / Acompanhamento  ';
  tabCalc := TTabSheet.Create(pgc); tabCalc.PageControl := pgc;
  tabCalc.Caption := '  Calculadora Fiscal  ';

  ConstruirTabNova;
  ConstruirTabRegistro;
  ConstruirTabCalc;
end;

procedure TfMain.ConstruirHeader;
begin
  pnlHeader := TPanel.Create(Self); pnlHeader.Parent := Self;
  pnlHeader.Align := alTop; pnlHeader.Height := 52;
  pnlHeader.Color := COR_ACCENT; pnlHeader.BevelOuter := bvNone;

  lblTitulo := TLabel.Create(Self); lblTitulo.Parent := pnlHeader;
  lblTitulo.Caption := 'Sistema de Devolucao NF-e v2.0';
  lblTitulo.Font.Size := 12; lblTitulo.Font.Style := [fsBold];
  lblTitulo.Font.Color := clWhite;
  lblTitulo.Left := 16; lblTitulo.Top := 16;

  // Botao SAIR — destacado no canto direito
  btnSair := NovoBotao(pnlHeader, 'SAIR  X', COR_DANGER, 110);
  btnSair.Width := 110; btnSair.Height := 36;
  btnSair.Font.Size := 10;
  btnSair.OnClick := @AcaoLogout;
  // posicionado depois (no resize)

  btnUsuarios := NovoBotao(pnlHeader, 'Usuarios', COR_ACCENT2, 100);
  btnUsuarios.OnClick := @AcaoUsuarios;

  lblUsuario := TLabel.Create(Self); lblUsuario.Parent := pnlHeader;
  lblUsuario.Font.Color := clWhite; lblUsuario.Font.Size := 9;
  lblUsuario.Top := 20;

  pnlHeader.OnResize := @procedure(Sender: TObject)
  begin
    btnSair.Left    := pnlHeader.Width - 120;
    btnSair.Top     := 8;
    btnUsuarios.Left := pnlHeader.Width - 230;
    btnUsuarios.Top  := 14;
    lblUsuario.Left  := pnlHeader.Width - 460;
  end;
end;

procedure TfMain.ConstruirFooter;
begin
  pnlFooter := TPanel.Create(Self); pnlFooter.Parent := Self;
  pnlFooter.Align := alBottom; pnlFooter.Height := 34;
  pnlFooter.Color := COR_BG_CARD; pnlFooter.BevelOuter := bvNone;

  lblFooter := TLabel.Create(Self); lblFooter.Parent := pnlFooter;
  lblFooter.Font.Color := COR_TEXT_MUTED; lblFooter.Font.Size := 8;
  lblFooter.Left := 10; lblFooter.Top := 10;

  btnFooterSair := NovoBotao(pnlFooter, 'Encerrar Sessao', COR_DANGER, 150);
  btnFooterSair.Height := 26; btnFooterSair.Top := 4;
  btnFooterSair.OnClick := @AcaoLogout;

  btnAlterarSenha := NovoBotao(pnlFooter, 'Alterar Minha Senha', COR_WARNING, 170);
  btnAlterarSenha.Height := 26; btnAlterarSenha.Top := 4;
  btnAlterarSenha.Font.Color := clBlack;
  btnAlterarSenha.OnClick := @AcaoAlterarSenha;

  pnlFooter.OnResize := @procedure(Sender: TObject)
  begin
    btnFooterSair.Left   := pnlFooter.Width - 164;
    btnAlterarSenha.Left := pnlFooter.Width - 344;
  end;
end;

procedure TfMain.ConstruirTabNova;
var
  tb: TPanel;
  grp: TGroupBox;

  procedure Grupo(const Tit: string; T: Integer);
  begin
    grp := TGroupBox.Create(Self); grp.Parent := scb;
    grp.Caption := Tit; grp.Top := T;
    grp.Width := 1200; grp.Height := 120;
    grp.Color := COR_BG_CARD; grp.Font.Color := COR_TEXT;
  end;

  function Ed(Grp: TGroupBox; L, T: Integer): TEdit;
  begin
    Result := NovoEdit(Grp); Result.Left := L; Result.Top := T; Result.Width := 160;
  end;

begin
  // Toolbar
  tb := TPanel.Create(Self); tb.Parent := tabNova;
  tb.Align := alTop; tb.Height := 44;
  tb.Color := COR_BG_DARK; tb.BevelOuter := bvNone;

  with NovoBotao(tb, 'Importar XML', COR_ACCENT) do
  begin Left := 8; Top := 7; OnClick := @AcaoImportarXML; end;
  with NovoBotao(tb, 'Salvar Nota', COR_ACCENT2) do
  begin Left := 158; Top := 7; OnClick := @AcaoSalvarNota; end;
  with NovoBotao(tb, 'Limpar', COR_DANGER, 100) do
  begin Left := 308; Top := 7; OnClick := @AcaoLimpar; end;
  with NovoBotao(tb, 'Exportar JSON', $FF4DFF, 140) do
  begin Left := 416; Top := 7; OnClick := @AcaoExportarJSON; end;

  scb := TScrollBox.Create(Self); scb.Parent := tabNova;
  scb.Align := alClient; scb.Color := COR_BG_DARK;
  scb.AutoScroll := True;

  // ── Identificacao ─────────────────────────────────────────────────────
  Grupo('1. IDENTIFICACAO DA NF-e', 8);
  NovoLbl(grp, 'Natureza Operacao').SetBounds(8,18,130,16);
  edtNatOp := Ed(grp, 8, 34);
  NovoLbl(grp, 'Serie').SetBounds(180,18,60,16);
  edtSerie := Ed(grp, 180, 34); edtSerie.Width := 60;
  NovoLbl(grp, 'Numero NF *').SetBounds(250,18,100,16);
  edtNumNF := Ed(grp, 250, 34); edtNumNF.Width := 100;
  NovoLbl(grp, 'CFOP *').SetBounds(360,18,60,16);
  edtCFOP := Ed(grp, 360, 34); edtCFOP.Width := 80;
  NovoLbl(grp, 'Data Emissao').SetBounds(450,18,110,16);
  edtDhEmi := Ed(grp, 450, 34);
  NovoLbl(grp, 'Finalidade (4=Dev)').SetBounds(620,18,140,16);
  edtFinNFe := Ed(grp, 620, 34); edtFinNFe.Width := 60;

  // ── Emitente ──────────────────────────────────────────────────────────
  Grupo('2. EMITENTE', 136);
  NovoLbl(grp, 'CNPJ *').SetBounds(8,18,80,16);
  edtEmitCNPJ := Ed(grp, 8, 34); edtEmitCNPJ.Width := 140;
  NovoLbl(grp, 'Razao Social *').SetBounds(158,18,120,16);
  edtEmitxNome := Ed(grp, 158, 34); edtEmitxNome.Width := 240;
  NovoLbl(grp, 'IE').SetBounds(408,18,40,16);
  edtEmitIE := Ed(grp, 408, 34); edtEmitIE.Width := 120;
  NovoLbl(grp, 'CRT').SetBounds(538,18,40,16);
  edtEmitCRT := Ed(grp, 538, 34); edtEmitCRT.Width := 60;
  NovoLbl(grp, 'Logradouro').SetBounds(8,64,100,16);
  edtEmitxLgr := Ed(grp, 8, 80); edtEmitxLgr.Width := 200;
  NovoLbl(grp, 'Numero').SetBounds(218,64,60,16);
  edtEmitNro := Ed(grp, 218, 80); edtEmitNro.Width := 60;
  NovoLbl(grp, 'Municipio').SetBounds(288,64,80,16);
  edtEmitxMun := Ed(grp, 288, 80); edtEmitxMun.Width := 160;
  NovoLbl(grp, 'UF').SetBounds(458,64,30,16);
  edtEmitUF := Ed(grp, 458, 80); edtEmitUF.Width := 40;
  NovoLbl(grp, 'CEP').SetBounds(508,64,40,16);
  edtEmitCEP := Ed(grp, 508, 80); edtEmitCEP.Width := 90;

  // ── Destinatario ──────────────────────────────────────────────────────
  Grupo('3. DESTINATARIO', 264);
  NovoLbl(grp, 'CNPJ/CPF *').SetBounds(8,18,90,16);
  edtDestCNPJ := Ed(grp, 8, 34); edtDestCNPJ.Width := 140;
  NovoLbl(grp, 'Razao Social *').SetBounds(158,18,120,16);
  edtDestxNome := Ed(grp, 158, 34); edtDestxNome.Width := 240;
  NovoLbl(grp, 'E-mail').SetBounds(408,18,60,16);
  edtDestEmail := Ed(grp, 408, 34); edtDestEmail.Width := 180;
  NovoLbl(grp, 'Logradouro').SetBounds(8,64,100,16);
  edtDestxLgr := Ed(grp, 8, 80); edtDestxLgr.Width := 200;
  NovoLbl(grp, 'Numero').SetBounds(218,64,60,16);
  edtDestNro := Ed(grp, 218, 80); edtDestNro.Width := 60;
  NovoLbl(grp, 'Municipio').SetBounds(288,64,80,16);
  edtDestxMun := Ed(grp, 288, 80); edtDestxMun.Width := 160;
  NovoLbl(grp, 'UF').SetBounds(458,64,30,16);
  edtDestUF := Ed(grp, 458, 80); edtDestUF.Width := 40;
  NovoLbl(grp, 'CEP').SetBounds(508,64,40,16);
  edtDestCEP := Ed(grp, 508, 80); edtDestCEP.Width := 90;

  // ── Produto ───────────────────────────────────────────────────────────
  Grupo('4. PRODUTO / SERVICO', 392);
  NovoLbl(grp, 'Cod.Prod *').SetBounds(8,18,80,16);
  edtProdcProd := Ed(grp, 8, 34); edtProdcProd.Width := 100;
  NovoLbl(grp, 'Descricao *').SetBounds(118,18,100,16);
  edtProdxProd := Ed(grp, 118, 34); edtProdxProd.Width := 240;
  NovoLbl(grp, 'NCM *').SetBounds(368,18,50,16);
  edtProdNCM := Ed(grp, 368, 34); edtProdNCM.Width := 80;
  NovoLbl(grp, 'Qtd').SetBounds(458,18,40,16);
  edtProdqCom := Ed(grp, 458, 34); edtProdqCom.Width := 80;
  NovoLbl(grp, 'Vl.Unit').SetBounds(548,18,60,16);
  edtProdvUnCom := Ed(grp, 548, 34); edtProdvUnCom.Width := 90;
  NovoLbl(grp, 'Vl.Total *').SetBounds(648,18,80,16);
  edtProdvProd := Ed(grp, 648, 34); edtProdvProd.Width := 100;
  NovoLbl(grp, 'Vl.Frete').SetBounds(8,64,70,16);
  edtProdvFrete := Ed(grp, 8, 80); edtProdvFrete.Width := 90;
  NovoLbl(grp, 'Desconto').SetBounds(108,64,70,16);
  edtProdvDesc := Ed(grp, 108, 80); edtProdvDesc.Width := 90;

  // ── ICMS + Reforma ────────────────────────────────────────────────────
  Grupo('5. ICMS + REFORMA TRIBUTARIA (CBS/IBS)', 520);
  grp.Height := 130;
  NovoLbl(grp, 'Origem').SetBounds(8,18,60,16);
  edtIcmsOrig := Ed(grp, 8, 34); edtIcmsOrig.Width := 40;
  NovoLbl(grp, 'CST').SetBounds(58,18,40,16);
  edtIcmsCST := Ed(grp, 58, 34); edtIcmsCST.Width := 40;
  NovoLbl(grp, 'BC ICMS').SetBounds(108,18,70,16);
  edtIcmsvBC := Ed(grp, 108, 34); edtIcmsvBC.Width := 90;
  NovoLbl(grp, 'Aliq.ICMS%').SetBounds(208,18,80,16);
  edtIcmspICMS := Ed(grp, 208, 34); edtIcmspICMS.Width := 80;
  NovoLbl(grp, 'Vl.ICMS').SetBounds(298,18,70,16);
  edtIcmsvICMS := Ed(grp, 298, 34); edtIcmsvICMS.Width := 90;
  // Reforma
  with TLabel.Create(Self) do begin
    Parent := grp; Caption := '--- Reforma Tributaria 2026 ---';
    Font.Color := COR_WARNING; Font.Style := [fsBold];
    Left := 8; Top := 66; end;
  NovoLbl(grp, 'Aliq.CBS%').SetBounds(8,84,70,16);
  edtRtpCBS := Ed(grp, 8, 100); edtRtpCBS.Width := 70;
  NovoLbl(grp, 'Vl.CBS').SetBounds(88,84,60,16);
  edtRtvCBS := Ed(grp, 88, 100); edtRtvCBS.Width := 80;
  NovoLbl(grp, 'Aliq.IBS%').SetBounds(178,84,70,16);
  edtRtpIBS := Ed(grp, 178, 100); edtRtpIBS.Width := 70;
  NovoLbl(grp, 'Vl.IBS').SetBounds(258,84,60,16);
  edtRtvIBS := Ed(grp, 258, 100); edtRtvIBS.Width := 80;

  // ── IPI ───────────────────────────────────────────────────────────────
  Grupo('6. IPI', 658);
  NovoLbl(grp, 'CST IPI').SetBounds(8,18,60,16);
  edtIpiCST := Ed(grp, 8, 34); edtIpiCST.Width := 50;
  NovoLbl(grp, 'Aliq.IPI%').SetBounds(68,18,70,16);
  edtIpipIPI := Ed(grp, 68, 34); edtIpipIPI.Width := 80;
  NovoLbl(grp, 'Vl.IPI').SetBounds(158,18,60,16);
  edtIpivIPI := Ed(grp, 158, 34); edtIpivIPI.Width := 90;

  // ── PIS/COFINS ────────────────────────────────────────────────────────
  Grupo('7. PIS / COFINS', 786);
  NovoLbl(grp, 'CST PIS').SetBounds(8,18,60,16);
  edtPisCST := Ed(grp, 8, 34); edtPisCST.Width := 50;
  NovoLbl(grp, 'Aliq.PIS%').SetBounds(68,18,70,16);
  edtPispPIS := Ed(grp, 68, 34); edtPispPIS.Width := 80;
  NovoLbl(grp, 'Vl.PIS').SetBounds(158,18,60,16);
  edtPisvPIS := Ed(grp, 158, 34); edtPisvPIS.Width := 90;
  NovoLbl(grp, 'CST COFINS').SetBounds(258,18,80,16);
  edtCofinsCST := Ed(grp, 258, 34); edtCofinsCST.Width := 50;
  NovoLbl(grp, 'Aliq.COF%').SetBounds(318,18,70,16);
  edtCofinspCOFINS := Ed(grp, 318, 34); edtCofinspCOFINS.Width := 80;
  NovoLbl(grp, 'Vl.COFINS').SetBounds(408,18,70,16);
  edtCofinsvCOFINS := Ed(grp, 408, 34); edtCofinsvCOFINS.Width := 90;

  // ── Totais ────────────────────────────────────────────────────────────
  Grupo('8. TOTAIS DA NF-e', 914);
  NovoLbl(grp, 'Vl.Produtos *').SetBounds(8,18,100,16);
  edtTotalvProd := Ed(grp, 8, 34); edtTotalvProd.Width := 110;
  NovoLbl(grp, 'Vl.ICMS').SetBounds(128,18,70,16);
  edtTotalvICMS := Ed(grp, 128, 34); edtTotalvICMS.Width := 100;
  NovoLbl(grp, 'Vl.PIS').SetBounds(238,18,60,16);
  edtTotalvPIS := Ed(grp, 238, 34); edtTotalvPIS.Width := 100;
  NovoLbl(grp, 'Vl.COFINS').SetBounds(348,18,80,16);
  edtTotalvCOFINS := Ed(grp, 348, 34); edtTotalvCOFINS.Width := 100;
  NovoLbl(grp, 'TOTAL NF *').SetBounds(458,18,80,16);
  edtTotalvNF := Ed(grp, 458, 34); edtTotalvNF.Width := 120;
  NovoLbl(grp, 'Total Tributos').SetBounds(588,18,100,16);
  edtTotalvTotTrib := Ed(grp, 588, 34); edtTotalvTotTrib.Width := 110;

  // ── Transporte ────────────────────────────────────────────────────────
  Grupo('9. TRANSPORTE', 1042);
  NovoLbl(grp, 'Modalidade').SetBounds(8,18,80,16);
  edtTranspModFrete := Ed(grp, 8, 34); edtTranspModFrete.Width := 60;
  NovoLbl(grp, 'Transportadora').SetBounds(78,18,110,16);
  edtTranspxNome := Ed(grp, 78, 34); edtTranspxNome.Width := 200;
  NovoLbl(grp, 'UF').SetBounds(288,18,30,16);
  edtTranspUF := Ed(grp, 288, 34); edtTranspUF.Width := 40;

  // ── Pagamento ─────────────────────────────────────────────────────────
  Grupo('10. PAGAMENTO', 1170);
  NovoLbl(grp, 'Forma Pagamento').SetBounds(8,18,120,16);
  edtPagtPag := Ed(grp, 8, 34); edtPagtPag.Width := 60;
  NovoLbl(grp, 'Vl.Pagamento').SetBounds(78,18,100,16);
  edtPagvPag := Ed(grp, 78, 34); edtPagvPag.Width := 120;

  // ── Informacoes Adicionais ────────────────────────────────────────────
  Grupo('11. INFORMACOES ADICIONAIS', 1298);
  grp.Height := 140;
  NovoLbl(grp, 'Informacoes Complementares').SetBounds(8,16,200,16);
  mmoInfCpl := TMemo.Create(Self); mmoInfCpl.Parent := grp;
  mmoInfCpl.SetBounds(8, 34, 1160, 44);
  mmoInfCpl.Color := COR_BG_FIELD; mmoInfCpl.Font.Color := COR_TEXT;
  NovoLbl(grp, 'Informacoes p/ Fisco').SetBounds(8,84,160,16);
  mmoInfAdFisco := TMemo.Create(Self); mmoInfAdFisco.Parent := grp;
  mmoInfAdFisco.SetBounds(8, 100, 1160, 30);
  mmoInfAdFisco.Color := COR_BG_FIELD; mmoInfAdFisco.Font.Color := COR_TEXT;
end;

procedure TfMain.ConstruirTabRegistro;
var
  tb: TPanel;
  I : Integer;
  Cols: array[0..7] of string = (
    'ID','N NF','Data Emissao','Emitente',
    'Destinatario','Valor Total','Status','Registrado em');
  Wids: array[0..7] of Integer = (50,80,120,220,220,100,100,140);
begin
  tb := TPanel.Create(Self); tb.Parent := tabReg;
  tb.Align := alTop; tb.Height := 44;
  tb.Color := COR_BG_DARK; tb.BevelOuter := bvNone;

  with TLabel.Create(Self) do begin
    Parent := tb; Caption := 'Buscar:';
    Font.Color := COR_TEXT_MUTED; Left := 8; Top := 14; end;

  edtBusca := TEdit.Create(Self); edtBusca.Parent := tb;
  edtBusca.Left := 68; edtBusca.Top := 8; edtBusca.Width := 220; edtBusca.Height := 26;
  edtBusca.Color := COR_BG_FIELD; edtBusca.Font.Color := COR_TEXT;
  edtBusca.OnKeyPress := @procedure(S: TObject; var K: Char)
    begin if K = #13 then AcaoBuscar(nil); end;

  with NovoBotao(tb, 'Buscar', COR_ACCENT, 90) do
  begin Left := 298; Top := 7; OnClick := @AcaoBuscar; end;
  with NovoBotao(tb, 'Atualizar', COR_ACCENT2, 100) do
  begin Left := 398; Top := 7;
    OnClick := @procedure(S: TObject) begin edtBusca.Text := ''; CarregarRegistros; end; end;
  with NovoBotao(tb, 'Carregar p/ Edicao', $FF4D7C, 160) do
  begin Left := 508; Top := 7; OnClick := @AcaoCarregarEditar; end;
  with NovoBotao(tb, 'Concluida', COR_SUCCESS, 100) do
  begin Left := 678; Top := 7;
    OnClick := @procedure(S: TObject) begin AcaoMudarStatus(STATUS_CONCLUIDA); end; end;
  with NovoBotao(tb, 'Cancelada', COR_DANGER, 100) do
  begin Left := 788; Top := 7;
    OnClick := @procedure(S: TObject) begin AcaoMudarStatus(STATUS_CANCELADA); end; end;

  sgNotas := TStringGrid.Create(Self); sgNotas.Parent := tabReg;
  sgNotas.Align := alClient;
  sgNotas.FixedRows := 1; sgNotas.RowCount := 2;
  sgNotas.ColCount := 8;
  sgNotas.Color := COR_BG_CARD; sgNotas.Font.Color := COR_TEXT;
  sgNotas.Options := sgNotas.Options + [goRowSelect, goColSizing] - [goEditing];

  for I := 0 to 7 do
  begin
    sgNotas.Cells[I, 0] := Cols[I];
    sgNotas.ColWidths[I] := Wids[I];
  end;
end;

procedure TfMain.ConstruirTabCalc;
var
  pCard, pRes: TPanel;

  procedure CRow(const Lbl: string; var Edt: TEdit; L, T: Integer);
  begin
    with TLabel.Create(Self) do begin
      Parent := pCard; Caption := Lbl;
      Font.Color := COR_TEXT_MUTED; Left := L; Top := T; end;
    Edt := TEdit.Create(Self); Edt.Parent := pCard;
    Edt.Left := L; Edt.Top := T + 18; Edt.Width := 140; Edt.Height := 24;
    Edt.Color := COR_BG_FIELD; Edt.Font.Color := COR_TEXT;
  end;

  procedure RLbl(const Cap: string; var Lbl: TLabel; L, T: Integer);
  begin
    with TLabel.Create(Self) do begin
      Parent := pRes; Caption := Cap;
      Font.Color := COR_TEXT_MUTED; Left := L; Top := T; end;
    Lbl := TLabel.Create(Self); Lbl.Parent := pRes;
    Lbl.Caption := 'R$ 0,00'; Lbl.Left := L; Lbl.Top := T + 16;
    Lbl.Font.Color := COR_ACCENT2; Lbl.Font.Style := [fsBold];
  end;

begin
  with TLabel.Create(Self) do begin
    Parent := tabCalc; Caption := 'Calculadora Fiscal — NF-e Devolucao';
    Font.Size := 13; Font.Style := [fsBold]; Font.Color := COR_ACCENT;
    Left := 40; Top := 16; end;

  pCard := TPanel.Create(Self); pCard.Parent := tabCalc;
  pCard.SetBounds(40, 50, 560, 320);
  pCard.Color := COR_BG_CARD; pCard.BevelOuter := bvNone;

  CRow('Valor dos Produtos (R$)', edtCvProd,  12, 12);
  CRow('Aliq. ICMS (%)',          edtCpICMS,  166, 12);
  CRow('Aliq. IPI (%)',           edtCpIPI,   320, 12);
  CRow('Aliq. PIS (%)',           edtCpPIS,   12, 60);
  CRow('Aliq. COFINS (%)',        edtCpCOFINS,166, 60);
  CRow('Aliq. CBS - Reforma (%)', edtCpCBS,   320, 60);
  CRow('Aliq. IBS - Reforma (%)', edtCpIBS,   12, 108);
  CRow('Desconto (%)',            edtCpDesc,  166, 108);
  CRow('Frete (%)',               edtCpFrete, 320, 108);

  with NovoBotao(pCard, 'Calcular Impostos', COR_ACCENT, 200) do
  begin Left := 12; Top := 158; Height := 36; Font.Size := 10;
    OnClick := @AcaoCalcular; end;

  pRes := TPanel.Create(Self); pRes.Parent := tabCalc;
  pRes.SetBounds(40, 380, 900, 140);
  pRes.Color := COR_BG_DARK; pRes.BevelOuter := bvNone;

  RLbl('Vl. ICMS',       lblRvICMS,   0,   0);
  RLbl('Vl. IPI',        lblRvIPI,    120, 0);
  RLbl('Vl. PIS',        lblRvPIS,    240, 0);
  RLbl('Vl. COFINS',     lblRvCOFINS, 360, 0);
  RLbl('Vl. CBS (Ref.)', lblRvCBS,    480, 0);
  RLbl('Vl. IBS (Ref.)', lblRvIBS,    600, 0);
  RLbl('Vl. Desconto',   lblRvDesc,   720, 0);
  RLbl('Vl. Frete',      lblRvFrete,  840, 0);

  RLbl('TOTAL NF',        lblRvTotal,  0,  60);
  lblRvTotal.Font.Color := COR_ACCENT; lblRvTotal.Font.Size := 12;
  RLbl('Total Tributos',  lblRvTrib,   200, 60);
end;

// ─────────────────────────────────────────────────────────────────────────────
// FORMULARIO — LEITURA E PREENCHIMENTO
// ─────────────────────────────────────────────────────────────────────────────
function TfMain.ObterDados: TDadosNFe;
begin
  FillChar(Result, SizeOf(Result), 0);
  Result.NatOp      := edtNatOp.Text;
  Result.Serie      := edtSerie.Text;
  Result.NumNF      := edtNumNF.Text;
  Result.CFOP       := edtCFOP.Text;
  Result.DhEmi      := edtDhEmi.Text;
  Result.FinNFe     := edtFinNFe.Text;
  Result.EmitCNPJ   := edtEmitCNPJ.Text;
  Result.EmitxNome  := edtEmitxNome.Text;
  Result.EmitIE     := edtEmitIE.Text;
  Result.EmitCRT    := edtEmitCRT.Text;
  Result.EmitxLgr   := edtEmitxLgr.Text;
  Result.EmitNro    := edtEmitNro.Text;
  Result.EmitxMun   := edtEmitxMun.Text;
  Result.EmitUF     := edtEmitUF.Text;
  Result.EmitCEP    := edtEmitCEP.Text;
  Result.DestCNPJ   := edtDestCNPJ.Text;
  Result.DestxNome  := edtDestxNome.Text;
  Result.DestEmail  := edtDestEmail.Text;
  Result.DestxLgr   := edtDestxLgr.Text;
  Result.DestNro    := edtDestNro.Text;
  Result.DestxMun   := edtDestxMun.Text;
  Result.DestUF     := edtDestUF.Text;
  Result.DestCEP    := edtDestCEP.Text;
  Result.ProdcProd  := edtProdcProd.Text;
  Result.ProdxProd  := edtProdxProd.Text;
  Result.ProdNCM    := edtProdNCM.Text;
  Result.ProdqCom   := edtProdqCom.Text;
  Result.ProdvUnCom := edtProdvUnCom.Text;
  Result.ProdvProd  := edtProdvProd.Text;
  Result.ProdvFrete := edtProdvFrete.Text;
  Result.ProdvDesc  := edtProdvDesc.Text;
  Result.IcmsOrig   := edtIcmsOrig.Text;
  Result.IcmsCST    := edtIcmsCST.Text;
  Result.IcmsvBC    := edtIcmsvBC.Text;
  Result.IcmspICMS  := edtIcmspICMS.Text;
  Result.IcmsvICMS  := edtIcmsvICMS.Text;
  Result.RtpCBS     := edtRtpCBS.Text;
  Result.RtvCBS     := edtRtvCBS.Text;
  Result.RtpIBS     := edtRtpIBS.Text;
  Result.RtvIBS     := edtRtvIBS.Text;
  Result.IpiCST     := edtIpiCST.Text;
  Result.IpipIPI    := edtIpipIPI.Text;
  Result.IpivIPI    := edtIpivIPI.Text;
  Result.PisCST         := edtPisCST.Text;
  Result.PispPIS        := edtPispPIS.Text;
  Result.PisvPIS        := edtPisvPIS.Text;
  Result.CofinsCST      := edtCofinsCST.Text;
  Result.CofinspCOFINS  := edtCofinspCOFINS.Text;
  Result.CofinsvCOFINS  := edtCofinsvCOFINS.Text;
  Result.TotalvProd     := edtTotalvProd.Text;
  Result.TotalvICMS     := edtTotalvICMS.Text;
  Result.TotalvPIS      := edtTotalvPIS.Text;
  Result.TotalvCOFINS   := edtTotalvCOFINS.Text;
  Result.TotalvNF       := edtTotalvNF.Text;
  Result.TotalvTotTrib  := edtTotalvTotTrib.Text;
  Result.TranspModFrete := edtTranspModFrete.Text;
  Result.TranspxNome    := edtTranspxNome.Text;
  Result.TranspUF       := edtTranspUF.Text;
  Result.PagtPag        := edtPagtPag.Text;
  Result.PagvPag        := edtPagvPag.Text;
  Result.InfCpl         := mmoInfCpl.Text;
  Result.InfAdFisco     := mmoInfAdFisco.Text;
end;

procedure TfMain.PreencherForm(const D: TDadosNFe);
begin
  edtNatOp.Text      := D.NatOp;
  edtSerie.Text      := D.Serie;
  edtNumNF.Text      := D.NumNF;
  edtCFOP.Text       := D.CFOP;
  edtDhEmi.Text      := D.DhEmi;
  edtFinNFe.Text     := D.FinNFe;
  edtEmitCNPJ.Text   := D.EmitCNPJ;
  edtEmitxNome.Text  := D.EmitxNome;
  edtEmitIE.Text     := D.EmitIE;
  edtEmitCRT.Text    := D.EmitCRT;
  edtEmitxLgr.Text   := D.EmitxLgr;
  edtEmitNro.Text    := D.EmitNro;
  edtEmitxMun.Text   := D.EmitxMun;
  edtEmitUF.Text     := D.EmitUF;
  edtEmitCEP.Text    := D.EmitCEP;
  edtDestCNPJ.Text   := D.DestCNPJ;
  edtDestxNome.Text  := D.DestxNome;
  edtDestEmail.Text  := D.DestEmail;
  edtDestxLgr.Text   := D.DestxLgr;
  edtDestNro.Text    := D.DestNro;
  edtDestxMun.Text   := D.DestxMun;
  edtDestUF.Text     := D.DestUF;
  edtDestCEP.Text    := D.DestCEP;
  edtProdcProd.Text  := D.ProdcProd;
  edtProdxProd.Text  := D.ProdxProd;
  edtProdNCM.Text    := D.ProdNCM;
  edtProdqCom.Text   := D.ProdqCom;
  edtProdvUnCom.Text := D.ProdvUnCom;
  edtProdvProd.Text  := D.ProdvProd;
  edtProdvFrete.Text := D.ProdvFrete;
  edtProdvDesc.Text  := D.ProdvDesc;
  edtIcmsOrig.Text   := D.IcmsOrig;
  edtIcmsCST.Text    := D.IcmsCST;
  edtIcmsvBC.Text    := D.IcmsvBC;
  edtIcmspICMS.Text  := D.IcmspICMS;
  edtIcmsvICMS.Text  := D.IcmsvICMS;
  edtRtpCBS.Text     := D.RtpCBS;
  edtRtvCBS.Text     := D.RtvCBS;
  edtRtpIBS.Text     := D.RtpIBS;
  edtRtvIBS.Text     := D.RtvIBS;
  edtIpiCST.Text     := D.IpiCST;
  edtIpipIPI.Text    := D.IpipIPI;
  edtIpivIPI.Text    := D.IpivIPI;
  edtPisCST.Text     := D.PisCST;
  edtPispPIS.Text    := D.PispPIS;
  edtPisvPIS.Text    := D.PisvPIS;
  edtCofinsCST.Text      := D.CofinsCST;
  edtCofinspCOFINS.Text  := D.CofinspCOFINS;
  edtCofinsvCOFINS.Text  := D.CofinsvCOFINS;
  edtTotalvProd.Text     := D.TotalvProd;
  edtTotalvICMS.Text     := D.TotalvICMS;
  edtTotalvPIS.Text      := D.TotalvPIS;
  edtTotalvCOFINS.Text   := D.TotalvCOFINS;
  edtTotalvNF.Text       := D.TotalvNF;
  edtTotalvTotTrib.Text  := D.TotalvTotTrib;
  edtTranspModFrete.Text := D.TranspModFrete;
  edtTranspxNome.Text    := D.TranspxNome;
  edtTranspUF.Text       := D.TranspUF;
  edtPagtPag.Text := D.PagtPag;
  edtPagvPag.Text := D.PagvPag;
  mmoInfCpl.Text     := D.InfCpl;
  mmoInfAdFisco.Text := D.InfAdFisco;
end;

procedure TfMain.LimparForm;
begin
  PreencherForm(Default(TDadosNFe));
  mmoInfCpl.Clear; mmoInfAdFisco.Clear;
end;

// ─────────────────────────────────────────────────────────────────────────────
// REGISTRO
// ─────────────────────────────────────────────────────────────────────────────
procedure TfMain.CarregarRegistros;
var
  Raw  : string;
  Lines: TStringList;
  Partes: TStringArray;
  R, I : Integer;
begin
  sgNotas.RowCount := 2;
  for I := 0 to 7 do sgNotas.Cells[I,1] := '';
  R := 1;

  Raw   := BuscarNotasSQL(edtBusca.Text);
  Lines := TStringList.Create;
  try
    Lines.Text := Raw;
    if Lines.Count > 0 then
      sgNotas.RowCount := Lines.Count + 1;
    for I := 0 to Lines.Count - 1 do
    begin
      if Trim(Lines[I]) = '' then Continue;
      Partes := Lines[I].Split(['|']);
      if Length(Partes) < 8 then Continue;
      sgNotas.Cells[0, R] := Partes[0];
      sgNotas.Cells[1, R] := Partes[1];
      sgNotas.Cells[2, R] := Partes[2];
      sgNotas.Cells[3, R] := Partes[3];
      sgNotas.Cells[4, R] := Partes[4];
      sgNotas.Cells[5, R] := FmtMoeda(ValorStr(Partes[5]));
      sgNotas.Cells[6, R] := Partes[6];
      sgNotas.Cells[7, R] := Partes[7];
      Inc(R);
    end;
  finally
    Lines.Free;
  end;
end;

// ─────────────────────────────────────────────────────────────────────────────
// ACOES
// ─────────────────────────────────────────────────────────────────────────────
procedure TfMain.AcaoImportarXML(Sender: TObject);
var
  Dlg  : TOpenDialog;
  Dados: TDadosNFe;
begin
  Dlg := TOpenDialog.Create(nil);
  try
    Dlg.Title  := 'Selecionar XML NF-e';
    Dlg.Filter := 'XML NF-e (*.xml)|*.xml|Todos (*.*)|*.*';
    if Dlg.Execute then
    begin
      if ParseXmlNFe(Dlg.FileName, Dados) then
      begin
        PreencherForm(Dados);
        ShowMessage('NF-e importada com sucesso!' + LineEnding +
          'NF: ' + Dados.NumNF + ' | Emitente: ' + Dados.EmitxNome);
      end
      else
        ShowMessage('Erro ao importar XML. Verifique se e uma NF-e 4.0 valida.');
    end;
  finally Dlg.Free; end;
end;

procedure TfMain.AcaoSalvarNota(Sender: TObject);
var
  D  : TDadosNFe;
  RID: Integer;
begin
  D := ObterDados;
  if (D.NumNF = '') or (D.EmitCNPJ = '') or (D.DestCNPJ = '') then
  begin ShowMessage('Preencha: Numero NF, CNPJ Emitente e CNPJ Destinatario.'); Exit; end;
  try
    RID := SalvarNota(D, DadosParaJSON(D));
    ShowMessage('Nota registrada com ID ' + IntToStr(RID));
    CarregarRegistros;
  except
    on E: Exception do ShowMessage('Erro ao salvar: ' + E.Message);
  end;
end;

procedure TfMain.AcaoLimpar(Sender: TObject);
begin
  if MessageDlg('Limpar todos os campos?', mtConfirmation, [mbYes,mbNo], 0) = mrYes then
    LimparForm;
end;

procedure TfMain.AcaoExportarJSON(Sender: TObject);
var
  Dlg: TSaveDialog;
  D  : TDadosNFe;
  F  : TextFile;
begin
  D   := ObterDados;
  Dlg := TSaveDialog.Create(nil);
  try
    Dlg.DefaultExt := 'json';
    Dlg.Filter     := 'JSON (*.json)|*.json';
    Dlg.FileName   := 'nfe_devolucao_' + D.NumNF + '.json';
    if Dlg.Execute then
    begin
      AssignFile(F, Dlg.FileName); Rewrite(F);
      Writeln(F, DadosParaJSON(D)); CloseFile(F);
      ShowMessage('Exportado: ' + Dlg.FileName);
    end;
  finally Dlg.Free; end;
end;

procedure TfMain.AcaoCalcular(Sender: TObject);
var
  vP, pICMS, pIPI, pPIS, pCOF: Double;
  pCBS, pIBS, pDes, pFrt      : Double;
  vDes, vFrt, base             : Double;
  vICMS, vIPI, vPIS, vCOF     : Double;
  vCBS, vIBS, vTrib, vTot     : Double;
begin
  vP   := ValorStr(edtCvProd.Text);
  pICMS := ValorStr(edtCpICMS.Text)   / 100;
  pIPI  := ValorStr(edtCpIPI.Text)    / 100;
  pPIS  := ValorStr(edtCpPIS.Text)    / 100;
  pCOF  := ValorStr(edtCpCOFINS.Text) / 100;
  pCBS  := ValorStr(edtCpCBS.Text)    / 100;
  pIBS  := ValorStr(edtCpIBS.Text)    / 100;
  pDes  := ValorStr(edtCpDesc.Text)   / 100;
  pFrt  := ValorStr(edtCpFrete.Text)  / 100;

  vDes  := vP * pDes;
  vFrt  := vP * pFrt;
  base  := vP - vDes + vFrt;
  vICMS := base * pICMS;
  vIPI  := base * pIPI;
  vPIS  := base * pPIS;
  vCOF  := base * pCOF;
  vCBS  := base * pCBS;
  vIBS  := base * pIBS;
  vTrib := vICMS + vIPI + vPIS + vCOF + vCBS + vIBS;
  vTot  := base + vIPI;

  lblRvICMS.Caption   := FmtMoeda(vICMS);
  lblRvIPI.Caption    := FmtMoeda(vIPI);
  lblRvPIS.Caption    := FmtMoeda(vPIS);
  lblRvCOFINS.Caption := FmtMoeda(vCOF);
  lblRvCBS.Caption    := FmtMoeda(vCBS);
  lblRvIBS.Caption    := FmtMoeda(vIBS);
  lblRvDesc.Caption   := FmtMoeda(vDes);
  lblRvFrete.Caption  := FmtMoeda(vFrt);
  lblRvTotal.Caption  := FmtMoeda(vTot);
  lblRvTrib.Caption   := FmtMoeda(vTrib);
end;

procedure TfMain.AcaoBuscar(Sender: TObject);
begin CarregarRegistros; end;

procedure TfMain.AcaoMudarStatus(const S: string);
var Row: Integer;
begin
  Row := sgNotas.Row;
  if Row < 1 then begin ShowMessage('Selecione uma nota.'); Exit; end;
  AtualizarStatus(StrToIntDef(sgNotas.Cells[0, Row], -1), S);
  CarregarRegistros;
end;

procedure TfMain.AcaoCarregarEditar(Sender: TObject);
var
  Row: Integer;
  ID : Integer;
  D  : TDadosNFe;
begin
  Row := sgNotas.Row;
  if Row < 1 then begin ShowMessage('Selecione uma nota.'); Exit; end;
  ID := StrToIntDef(sgNotas.Cells[0, Row], -1);
  if ID < 0 then Exit;
  JSONParaDados(CarregarNotaJSON(ID), D);
  PreencherForm(D);
  pgc.ActivePage := tabNova;
  ShowMessage('Nota ID ' + IntToStr(ID) + ' carregada para edicao.');
end;

procedure TfMain.AcaoLogout(Sender: TObject);
begin
  if MessageDlg('Encerrar sessao e voltar ao login?',
     mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    with TfLogin.Create(nil) do
    try
      if ShowModal = mrOk then
      begin
        fMain.Inicializar(UsuarioLogado);
        Show;
      end;
    finally Free; end;
  end;
end;

procedure TfMain.AcaoAlterarSenha(Sender: TObject);
begin ShowAlterarSenha(FUsuario.Login); end;

procedure TfMain.AcaoUsuarios(Sender: TObject);
begin
  if FUsuario.Perfil <> puAdmin then
  begin ShowMessage('Apenas administradores.'); Exit; end;
  ShowGerenciarUsuarios;
end;

// Ctrl+Q global logout
procedure TfMain.DoKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if (Key = Ord('Q')) and (ssCtrl in Shift) then
    AcaoLogout(nil);
end;

// Forma de criar o form dinamicamente (sem .lfm)
procedure TfMain.AdicionarSecao(const Titulo: string;
  Campos: array of string; var Edts: array of TEdit);
begin
  // Stub — UI criada em ConstruirUI
end;

// Registra o form sem arquivo .lfm
initialization
  // O form e criado dinamicamente em ConstruirUI, sem arquivo .lfm
  // Para Lazarus, precisamos de um .lfm minimo — ver nota no workflow

end.
