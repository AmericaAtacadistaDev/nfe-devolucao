unit frmLogin;

{$mode objfpc}{$H+}

interface

uses
  SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, ExtCtrls, ComCtrls,
  uConstantes, uBancoDados, uSeguranca;

// ── Tela de Login ─────────────────────────────────────────────────────────────
type
  TfLogin = class(TForm)
  private
    edtLogin, edtSenha: TEdit;
    btnEntrar         : TBitBtn;
    btnEsqueci        : TButton;
    btnOlho           : TButton;
    chkLembrar        : TCheckBox;
    lblErro           : TLabel;
    tmrBlq            : TTimer;
    FTentativas       : Integer;
    FBloqueadoAte     : TDateTime;
    FMostrarSenha     : Boolean;
    procedure Construir;
    procedure DoEntrar(Sender: TObject);
    procedure DoOlho(Sender: TObject);
    procedure DoEsqueci(Sender: TObject);
    procedure DoTimer(Sender: TObject);
    procedure DoKeyLogin(Sender: TObject; var Key: Char);
    procedure DoKeySenha(Sender: TObject; var Key: Char);
  public
    UsuarioLogado: TUsuario;
    constructor Create(AOwner: TComponent); override;
  end;

// ── Tela de Primeiro Acesso ───────────────────────────────────────────────────
type
  TfPrimeiroAcesso = class(TForm)
  private
    edtNome, edtLogin: TEdit;
    edtSenha, edtConf: TEdit;
    pbForca          : TProgressBar;
    lblForca, lblErro: TLabel;
    procedure Construir;
    procedure DoCriar(Sender: TObject);
    procedure DoForca(Sender: TObject);
    procedure DoKey(Sender: TObject; var Key: Char);
  public
    UsuarioCriado: TUsuario;
    constructor Create(AOwner: TComponent); override;
  end;

procedure ShowAlterarSenha(const Login: string);
procedure ShowGerenciarUsuarios;

var
  fMain_ref: TForm = nil;  // referencia para logout

implementation

uses
  DateUtils, IniFiles;

// ─────────────────────────────────────────────────────────────────────────────
// HELPER: cria label + edit padronizados
// ─────────────────────────────────────────────────────────────────────────────
function MkLabel(Owner: TWinControl; const Txt: string; X, Y: Integer): TLabel;
begin
  Result := TLabel.Create(Owner);
  Result.Parent  := Owner;
  Result.Caption := Txt;
  Result.Left    := X; Result.Top := Y;
  Result.Font.Color := COR_TEXT_MUTED;
end;

function MkEdit(Owner: TWinControl; X, Y, W: Integer; Senha: Boolean = False): TEdit;
begin
  Result := TEdit.Create(Owner);
  Result.Parent := Owner;
  Result.Left := X; Result.Top := Y; Result.Width := W; Result.Height := 26;
  Result.Color     := COR_BG_FIELD;
  Result.Font.Color := COR_TEXT;
  if Senha then Result.PasswordChar := '*';
end;

function MkBtn(Owner: TWinControl; const Cap: string; X, Y, W: Integer;
               Cor: TColor): TBitBtn;
begin
  Result := TBitBtn.Create(Owner);
  Result.Parent  := Owner;
  Result.Caption := Cap;
  Result.Left    := X; Result.Top := Y;
  Result.Width   := W; Result.Height := 34;
  Result.Color      := Cor;
  Result.Font.Color := clWhite;
  Result.Font.Style := [fsBold];
  Result.Flat := True;
end;

// ─────────────────────────────────────────────────────────────────────────────
// TELA DE LOGIN
// ─────────────────────────────────────────────────────────────────────────────
constructor TfLogin.Create(AOwner: TComponent);
begin
  inherited CreateNew(AOwner);
  FTentativas   := 0;
  FMostrarSenha := False;
  Construir;

  // Carrega login lembrado
  declare
    Ini: TIniFile;
    Cfg: string;
  begin
    Cfg := ExtractFilePath(DB_PATH) + '.nfe_config.ini';
    if FileExists(Cfg) then
    begin
      Ini := TIniFile.Create(Cfg);
      try
        if Ini.ReadBool('Login','Lembrar',False) then
        begin
          edtLogin.Text := Ini.ReadString('Login','UltimoLogin','');
          chkLembrar.Checked := True;
          edtSenha.SetFocus;
        end;
      finally Ini.Free; end;
    end;
  end;
end;

procedure TfLogin.Construir;
var
  pTop, pCard: TPanel;
  lLogin, lSenha: TLabel;
  sfRow: TPanel;
begin
  Caption     := 'Login — ' + APP_TITLE;
  Width       := 480; Height := 540;
  Position    := poScreenCenter;
  BorderStyle := bsDialog;
  Color       := COR_BG_DARK;

  pTop := TPanel.Create(Self); pTop.Parent := Self;
  pTop.Align := alTop; pTop.Height := 6;
  pTop.Color := COR_ACCENT; pTop.BevelOuter := bvNone;

  // Icone e titulo
  with TLabel.Create(Self) do begin
    Parent := Self; Caption := 'Sistema de Devolucao NF-e';
    Font.Size := 14; Font.Style := [fsBold]; Font.Color := COR_TEXT;
    Left := 0; Top := 30; AutoSize := True; Align := alNone;
    Left := (480 - Width) div 2;
  end;
  with TLabel.Create(Self) do begin
    Parent := Self; Caption := 'v2.0  |  Acesso Restrito';
    Font.Color := COR_TEXT_MUTED; Font.Size := 9;
    Top := 58; AutoSize := True;
    Left := (480 - Width) div 2;
  end;

  pCard := TPanel.Create(Self); pCard.Parent := Self;
  pCard.Left := 32; pCard.Top := 88;
  pCard.Width := 416; pCard.Height := 240;
  pCard.Color := COR_BG_CARD; pCard.BevelOuter := bvNone;

  lLogin := MkLabel(pCard, 'Usuario', 16, 14);
  edtLogin := MkEdit(pCard, 16, 34, 384);
  edtLogin.OnKeyPress := @DoKeyLogin;

  lSenha := MkLabel(pCard, 'Senha', 16, 78);

  sfRow := TPanel.Create(pCard); sfRow.Parent := pCard;
  sfRow.Left := 16; sfRow.Top := 96; sfRow.Width := 384; sfRow.Height := 28;
  sfRow.Color := COR_BG_CARD; sfRow.BevelOuter := bvNone;

  edtSenha := MkEdit(sfRow, 0, 0, 348, True);
  edtSenha.Width := 344; edtSenha.Height := 28;
  edtSenha.OnKeyPress := @DoKeySenha;

  btnOlho := TButton.Create(sfRow); btnOlho.Parent := sfRow;
  btnOlho.Caption := 'Ver'; btnOlho.Left := 348; btnOlho.Top := 0;
  btnOlho.Width := 36; btnOlho.Height := 28;
  btnOlho.OnClick := @DoOlho;

  chkLembrar := TCheckBox.Create(pCard); chkLembrar.Parent := pCard;
  chkLembrar.Caption := 'Lembrar usuario';
  chkLembrar.Left := 16; chkLembrar.Top := 140;
  chkLembrar.Font.Color := COR_TEXT_MUTED;

  lblErro := TLabel.Create(Self); lblErro.Parent := Self;
  lblErro.Caption := ''; lblErro.Font.Color := COR_DANGER;
  lblErro.Left := 32; lblErro.Top := 342; lblErro.Width := 416;
  lblErro.WordWrap := True;

  btnEntrar := MkBtn(Self, 'Entrar  ->', 32, 370, 416, COR_ACCENT);
  btnEntrar.OnClick := @DoEntrar;

  btnEsqueci := TButton.Create(Self); btnEsqueci.Parent := Self;
  btnEsqueci.Caption := 'Esqueci minha senha';
  btnEsqueci.Left := 32; btnEsqueci.Top := 414;
  btnEsqueci.Width := 200; btnEsqueci.Height := 28;
  btnEsqueci.Color := COR_BG_DARK; btnEsqueci.Font.Color := COR_TEXT_MUTED;
  btnEsqueci.Flat := True;
  btnEsqueci.OnClick := @DoEsqueci;

  with TLabel.Create(Self) do begin
    Parent := Self;
    Caption := Format('(c) %d  Sistema NF-e  |  Acesso monitorado', [YearOf(Now)]);
    Font.Color := COR_BORDER; Font.Size := 8;
    Left := 32; Top := 460;
  end;

  tmrBlq := TTimer.Create(Self);
  tmrBlq.Interval := 1000; tmrBlq.Enabled := False;
  tmrBlq.OnTimer := @DoTimer;
end;

procedure TfLogin.DoEntrar(Sender: TObject);
var
  U: TUsuario;
  Ini: TIniFile;
  Cfg: string;
begin
  if FBloqueadoAte > 0 then
  begin
    lblErro.Caption := Format('Bloqueado. Aguarde %d s.',
      [SecondsBetween(Now, FBloqueadoAte)]);
    Exit;
  end;
  if (edtLogin.Text = '') or (edtSenha.Text = '') then
  begin lblErro.Caption := 'Informe usuario e senha.'; Exit; end;

  U := Autenticar(edtLogin.Text, edtSenha.Text);
  if U.ID > 0 then
  begin
    FTentativas := 0;
    // Salva preferencia lembrar
    Cfg := ExtractFilePath(DB_PATH) + '.nfe_config.ini';
    Ini := TIniFile.Create(Cfg);
    try
      Ini.WriteBool('Login','Lembrar', chkLembrar.Checked);
      if chkLembrar.Checked then
        Ini.WriteString('Login','UltimoLogin', edtLogin.Text)
      else
        Ini.WriteString('Login','UltimoLogin', '');
    finally Ini.Free; end;
    UsuarioLogado := U;
    ModalResult   := mrOk;
  end
  else
  begin
    Inc(FTentativas);
    edtSenha.Text := '';
    edtSenha.SetFocus;
    if FTentativas >= MAX_TENTATIVAS then
    begin
      FBloqueadoAte     := IncSecond(Now, BLOQUEIO_SEGUNDOS);
      tmrBlq.Enabled    := True;
      btnEntrar.Enabled := False;
      lblErro.Caption   := Format(
        '%d tentativas incorretas. Bloqueado por %d segundos.',
        [MAX_TENTATIVAS, BLOQUEIO_SEGUNDOS]);
    end
    else
      lblErro.Caption := Format(
        'Usuario ou senha incorretos. (%d tentativa(s) restante(s))',
        [MAX_TENTATIVAS - FTentativas]);
  end;
end;

procedure TfLogin.DoOlho(Sender: TObject);
begin
  FMostrarSenha := not FMostrarSenha;
  if FMostrarSenha then
  begin edtSenha.PasswordChar := #0; btnOlho.Caption := 'Ocultar'; end
  else
  begin edtSenha.PasswordChar := '*'; btnOlho.Caption := 'Ver'; end;
end;

procedure TfLogin.DoEsqueci(Sender: TObject);
begin ShowAlterarSenha(''); end;

procedure TfLogin.DoTimer(Sender: TObject);
var R: Integer;
begin
  R := SecondsBetween(Now, FBloqueadoAte);
  if R > 0 then
    lblErro.Caption := Format('Conta bloqueada. Aguarde %d s.', [R])
  else
  begin
    tmrBlq.Enabled := False; FBloqueadoAte := 0; FTentativas := 0;
    lblErro.Caption := ''; btnEntrar.Enabled := True;
  end;
end;

procedure TfLogin.DoKeyLogin(Sender: TObject; var Key: Char);
begin if Key = #13 then edtSenha.SetFocus; end;
procedure TfLogin.DoKeySenha(Sender: TObject; var Key: Char);
begin if Key = #13 then DoEntrar(nil); end;

// ─────────────────────────────────────────────────────────────────────────────
// TELA DE PRIMEIRO ACESSO
// ─────────────────────────────────────────────────────────────────────────────
constructor TfPrimeiroAcesso.Create(AOwner: TComponent);
begin
  inherited CreateNew(AOwner);
  Construir;
end;

procedure TfPrimeiroAcesso.Construir;
var
  pTop, pCard: TPanel;
begin
  Caption     := 'Primeiro Acesso — ' + APP_TITLE;
  Width       := 520; Height := 540;
  Position    := poScreenCenter;
  BorderStyle := bsDialog;
  Color       := COR_BG_DARK;

  pTop := TPanel.Create(Self); pTop.Parent := Self;
  pTop.Align := alTop; pTop.Height := 8;
  pTop.Color := COR_ACCENT2; pTop.BevelOuter := bvNone;

  with TLabel.Create(Self) do begin
    Parent := Self; Caption := 'Primeiro Acesso ao Sistema';
    Font.Size := 14; Font.Style := [fsBold]; Font.Color := COR_TEXT;
    Left := 32; Top := 22;
  end;
  with TLabel.Create(Self) do begin
    Parent := Self; Caption := 'Crie o usuario Administrador para comecar';
    Font.Color := COR_TEXT_MUTED; Left := 32; Top := 50;
  end;

  pCard := TPanel.Create(Self); pCard.Parent := Self;
  pCard.Left := 32; pCard.Top := 78; pCard.Width := 456; pCard.Height := 330;
  pCard.Color := COR_BG_CARD; pCard.BevelOuter := bvNone;

  MkLabel(pCard, 'Nome completo *', 16, 14);
  edtNome  := MkEdit(pCard, 16, 34, 424);
  edtNome.OnKeyPress := @DoKey;

  MkLabel(pCard, 'Login (usuario) *', 16, 74);
  edtLogin := MkEdit(pCard, 16, 94, 424);
  edtLogin.OnKeyPress := @DoKey;

  MkLabel(pCard, 'Senha *', 16, 134);
  edtSenha := MkEdit(pCard, 16, 154, 424, True);
  edtSenha.OnChange := @DoForca;
  edtSenha.OnKeyPress := @DoKey;

  MkLabel(pCard, 'Confirmar senha *', 16, 194);
  edtConf  := MkEdit(pCard, 16, 214, 424, True);
  edtConf.OnKeyPress := @DoKey;

  pbForca := TProgressBar.Create(pCard); pbForca.Parent := pCard;
  pbForca.Left := 16; pbForca.Top := 258; pbForca.Width := 424; pbForca.Height := 10;
  pbForca.Min := 0; pbForca.Max := 5;

  lblForca := MkLabel(pCard, '', 16, 272);

  with TLabel.Create(pCard) do begin
    Parent := pCard;
    Caption := 'Perfil: Administrador (unico no primeiro acesso)';
    Font.Color := COR_ACCENT2; Font.Style := [fsItalic];
    Left := 16; Top := 296;
  end;

  lblErro := TLabel.Create(Self); lblErro.Parent := Self;
  lblErro.Caption := ''; lblErro.Font.Color := COR_DANGER;
  lblErro.Left := 32; lblErro.Top := 422; lblErro.Width := 456;

  with MkBtn(Self, 'Criar Administrador e Entrar', 32, 448, 456, COR_ACCENT2) do
  begin
    Font.Color := clBlack;
    OnClick := @DoCriar;
  end;
end;

procedure TfPrimeiroAcesso.DoForca(Sender: TObject);
var
  S: Integer;
  Cores: array[0..5] of TColor = (clBlack, COR_DANGER, COR_WARNING, COR_WARNING, COR_ACCENT2, COR_SUCCESS);
  Textos: array[0..5] of string = ('','Muito fraca','Fraca','Media','Boa','Forte');
begin
  S := ValidarForcaSenha(edtSenha.Text);
  pbForca.Position := S;
  lblForca.Caption := Textos[S];
  lblForca.Font.Color := Cores[S];
end;

procedure TfPrimeiroAcesso.DoCriar(Sender: TObject);
var
  Nome, Login, Senha, Conf: string;
begin
  Nome  := Trim(edtNome.Text);
  Login := Trim(edtLogin.Text);
  Senha := edtSenha.Text;
  Conf  := edtConf.Text;

  if (Nome='') or (Login='') or (Senha='') then
  begin lblErro.Caption := 'Preencha todos os campos.'; Exit; end;
  if Length(Login) < 3 then
  begin lblErro.Caption := 'Login minimo: 3 caracteres.'; Exit; end;
  if Length(Senha) < 6 then
  begin lblErro.Caption := 'Senha minima: 6 caracteres.'; Exit; end;
  if Senha <> Conf then
  begin lblErro.Caption := 'As senhas nao coincidem.'; Exit; end;
  if not CriarUsuario(Nome, Login, Senha, 'admin') then
  begin lblErro.Caption := 'Login ja existe. Escolha outro.'; Exit; end;

  UsuarioCriado.ID     := 1;
  UsuarioCriado.Nome   := Nome;
  UsuarioCriado.Login  := Login;
  UsuarioCriado.Perfil := puAdmin;
  UsuarioCriado.Ativo  := True;
  ModalResult := mrOk;
end;

procedure TfPrimeiroAcesso.DoKey(Sender: TObject; var Key: Char);
begin
  if Key <> #13 then Exit;
  if Sender = edtNome  then edtLogin.SetFocus
  else if Sender = edtLogin then edtSenha.SetFocus
  else if Sender = edtSenha then edtConf.SetFocus
  else if Sender = edtConf  then DoCriar(nil);
end;

// ─────────────────────────────────────────────────────────────────────────────
// JANELA: ALTERAR SENHA
// ─────────────────────────────────────────────────────────────────────────────
procedure ShowAlterarSenha(const Login: string);
var
  Frm    : TForm;
  eLogin : TEdit;
  eNova  : TEdit;
  eConf  : TEdit;
  pb     : TProgressBar;
  lblMsg : TLabel;

  procedure DoSalvar(Sender: TObject);
  var L, N, C: string;
  begin
    L := Trim(eLogin.Text); N := eNova.Text; C := eConf.Text;
    if (L='') or (N='') then begin lblMsg.Caption := 'Preencha todos os campos.'; Exit; end;
    if Length(N) < 6 then begin lblMsg.Caption := 'Minimo 6 caracteres.'; Exit; end;
    if N <> C then begin lblMsg.Caption := 'As senhas nao coincidem.'; Exit; end;
    if AlterarSenha(L, N) then
    begin lblMsg.Caption := 'Senha alterada com sucesso!'; lblMsg.Font.Color := COR_SUCCESS;
      Frm.ModalResult := mrOk; end
    else
    begin lblMsg.Caption := 'Usuario nao encontrado.'; lblMsg.Font.Color := COR_DANGER; end;
  end;

  procedure DoForca(Sender: TObject);
  begin pb.Position := ValidarForcaSenha(eNova.Text); end;

begin
  Frm := TForm.CreateNew(nil);
  try
    Frm.Caption     := 'Redefinir Senha';
    Frm.Width       := 460; Frm.Height := 440;
    Frm.Position    := poScreenCenter;
    Frm.BorderStyle := bsDialog;
    Frm.Color       := COR_BG_DARK;

    with TPanel.Create(Frm) do begin
      Parent := Frm; Align := alTop; Height := 6;
      Color := COR_WARNING; BevelOuter := bvNone; end;

    MkLabel(Frm, 'Redefinir Senha', 32, 20).Font.Size := 13;

    MkLabel(Frm, 'Login do usuario *', 32, 58);
    eLogin := MkEdit(Frm, 32, 76, 396);
    eLogin.Text := Login;

    MkLabel(Frm, 'Nova senha *', 32, 116);
    eNova := MkEdit(Frm, 32, 134, 396, True);
    eNova.OnChange := @DoForca;

    pb := TProgressBar.Create(Frm); pb.Parent := Frm;
    pb.Left := 32; pb.Top := 168; pb.Width := 396; pb.Height := 8;
    pb.Min := 0; pb.Max := 5;

    MkLabel(Frm, 'Confirmar *', 32, 186);
    eConf := MkEdit(Frm, 32, 204, 396, True);

    lblMsg := TLabel.Create(Frm); lblMsg.Parent := Frm;
    lblMsg.Caption := ''; lblMsg.Font.Color := COR_DANGER;
    lblMsg.Left := 32; lblMsg.Top := 244; lblMsg.Width := 396;

    with MkBtn(Frm, 'Redefinir Senha', 32, 274, 230, COR_WARNING) do
    begin Font.Color := clBlack; OnClick := @DoSalvar; end;
    with MkBtn(Frm, 'Cancelar', 272, 274, 156, COR_BORDER) do
    begin ModalResult := mrCancel; end;

    Frm.ShowModal;
  finally
    Frm.Free;
  end;
end;

// ─────────────────────────────────────────────────────────────────────────────
// JANELA: GERENCIAR USUARIOS
// ─────────────────────────────────────────────────────────────────────────────
procedure ShowGerenciarUsuarios;
var
  Frm  : TForm;
  lv   : TListBox;
  Lines: TStringList;

  procedure Carregar;
  var
    Raw, Line: string;
    Partes: TStringArray;
    I: Integer;
  begin
    lv.Items.Clear;
    Raw := ListarUsuariosSQL;
    Lines := TStringList.Create;
    try
      Lines.Text := Raw;
      for I := 0 to Lines.Count - 1 do
      begin
        Line := Lines[I];
        if Line = '' then Continue;
        Partes := Line.Split(['|']);
        if Length(Partes) >= 5 then
          lv.Items.Add(Format('ID:%-4s  %-24s  %-16s  %-10s  %s',
            [Partes[0], Partes[1], Partes[2], Partes[3],
             IfThen(Partes[4]='1','Ativo','Inativo')]));
      end;
    finally Lines.Free; end;
  end;

  function SelID: Integer;
  var S: string; P: Integer;
  begin
    Result := -1;
    if lv.ItemIndex < 0 then Exit;
    S := lv.Items[lv.ItemIndex];
    S := Trim(Copy(S, 4, 4));
    Result := StrToIntDef(S, -1);
  end;

  procedure DoDes(Sender: TObject);
  begin
    if SelID < 0 then begin ShowMessage('Selecione um usuario.'); Exit; end;
    if MessageDlg('Desativar este usuario?', mtConfirmation, [mbYes,mbNo], 0) = mrYes then
    begin DesativarUsuario(SelID); Carregar; end;
  end;

  procedure DoReat(Sender: TObject);
  begin
    if SelID < 0 then begin ShowMessage('Selecione um usuario.'); Exit; end;
    ReativarUsuario(SelID); Carregar;
  end;

  procedure DoEdit(Sender: TObject);
  var Raw, Line: string; Partes: TStringArray; I: Integer;
  begin
    if SelID < 0 then begin ShowMessage('Selecione um usuario.'); Exit; end;
    Raw := ListarUsuariosSQL;
    Lines := TStringList.Create;
    try
      Lines.Text := Raw; I := lv.ItemIndex;
      if I < Lines.Count then
      begin
        Line := Lines[I]; Partes := Line.Split(['|']);
        if Length(Partes) >= 3 then ShowAlterarSenha(Partes[2]);
      end;
    finally Lines.Free; end;
  end;

begin
  Frm := TForm.CreateNew(nil);
  try
    Frm.Caption := 'Gerenciar Usuarios — ' + APP_TITLE;
    Frm.Width := 860; Frm.Height := 520;
    Frm.Position := poScreenCenter;
    Frm.Color := COR_BG_DARK;

    with TPanel.Create(Frm) do begin
      Parent := Frm; Align := alTop; Height := 6;
      Color := COR_ACCENT; BevelOuter := bvNone; end;

    MkLabel(Frm, 'Gerenciamento de Usuarios', 12, 14).Font.Size := 12;

    with MkBtn(Frm,'Alterar Senha',  12, 42, 140, COR_WARNING) do OnClick := @DoEdit;
    with MkBtn(Frm,'Desativar',     162, 42, 110, COR_DANGER)  do OnClick := @DoDes;
    with MkBtn(Frm,'Reativar',      282, 42, 110, COR_ACCENT2) do OnClick := @DoReat;
    with MkBtn(Frm,'Atualizar',     402, 42, 110, COR_BORDER)  do OnClick := @procedure(S:TObject) begin Carregar; end;

    lv := TListBox.Create(Frm); lv.Parent := Frm;
    lv.Left := 12; lv.Top := 88; lv.Width := 830; lv.Height := 380;
    lv.Color := COR_BG_CARD; lv.Font.Color := COR_TEXT;
    lv.Font.Name := 'Courier New';

    Carregar;
    Frm.ShowModal;
  finally
    Frm.Free;
  end;
end;

end.
